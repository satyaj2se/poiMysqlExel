/**
 * 
 */
package org.kpcc.ws.ppcl.file.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.kpcc.ws.ppcl.constants.PPCLConstant;
import org.kpcc.ws.ppcl.dto.PPCLHISDBBenIfoStageDTO;
import org.kpcc.ws.ppcl.dto.PPCLHISDBCarrierStageDTO;
import org.kpcc.ws.ppcl.exception.BusinessExceptionMessage;
import org.kpcc.ws.ppcl.properties.ApplicationProperties;
import org.kpcc.ws.ppcl.repo.PPCLHISDBBenInfoStageRepo;
import org.kpcc.ws.ppcl.repo.PPCLHISDBCarrierRepo;
import org.kpcc.ws.ppcl.utils.DataValidatorUtil;
import org.kpcc.ws.ppcl.utils.DatabaseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

/**
 * @author F998022
 *
 */
@Component
public class ProcessHISDBCalOptimaFile {
	private static Logger logger = LogManager.getLogger(ProcessHISDBCalOptimaFile.class);

	@Autowired
	private PPCLHISDBBenInfoStageRepo benInfoRepo;

	@Autowired
	private PPCLHISDBCarrierRepo ohcStageRepo;

	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * This method will process the PPCL data from the HISDBLIKE file passed,
	 * 
	 * @param lzMap
	 * @param lzFile
	 * @return
	 */
	public String processHisDBLikeCalData(Map<String, String> lzMap, File lzFile) {
		logger.info("ProcessHISDBCALOPTIMAFile : HISDB file data processing initiated...");
		String status = "";

		if (lzFile != null) {
			List<String> lines = new ArrayList<>();

			String workingPath = lzMap.get(PPCLConstant.LOADER_WORKING_PATH);
			String errorPath = lzMap.get(PPCLConstant.LOADER_ERROR_PATH);
			try (BufferedReader br = Files.newBufferedReader(Paths.get(lzFile.getPath()))) {
				lines = br.lines().collect(Collectors.toList());
				// read each line from the given file.
				if (CollectionUtils.isEmpty(lines)) {
					throw new BusinessExceptionMessage("No data available in the given file " + lzFile.getName());
				} else {
					for (String str : lines) {
						try {
							if (StringUtils.isBlank(str)) {
								throw new BusinessExceptionMessage("Invalid data indentified");
							} else {
								PPCLHISDBBenIfoStageDTO benInfo = processMemberSegment(str.substring(0, 83));
								List<PPCLHISDBCarrierStageDTO> ohcSegList = processOHCSegment(benInfo,
										str.substring(83, str.trim().length()));

								status = (benInfo != null && !ohcSegList.isEmpty()) ? "Success" : "Failed";
							}
						} catch(Exception e) {
							logger.error("Error occured while processing the data: "+e.getMessage());
						}
					}
					if (status.equalsIgnoreCase("Success")) {
						moveFile(lzFile, workingPath);
					} else {
						moveFile(lzFile, errorPath);
					}
				}
			} catch (BusinessExceptionMessage be) {
				logger.error("Unable to process the HISDBLike data due to : " + be.getMessage());
				status = "Failed";
				moveFile(lzFile, errorPath);
			} catch (IOException ie) {
				logger.error("Error occured while processing the data : " + ie.getMessage());
				status = "Failed";
				moveFile(lzFile, errorPath);
			}
		} else {
			status = "Failed";
		}
		return status;
	}

	/**
	 * This method will fetch the member info from the given String, as per the
	 * HISDB-CALOPTIMA details provided
	 * 
	 * @param memInfo
	 * @return
	 */
	@Transactional
	private PPCLHISDBBenIfoStageDTO processMemberSegment(String memInfo) {
		PPCLHISDBBenIfoStageDTO ppclMembrSegmnt = new PPCLHISDBBenIfoStageDTO();
		String regionCode = ApplicationProperties.getRegion();
		ppclMembrSegmnt.setRegionCode(regionCode);
		ppclMembrSegmnt.setMedsId(memInfo.substring(0, 9));
		ppclMembrSegmnt.setNbrOfInsuranceSegments(memInfo.substring(9, 11));
		ppclMembrSegmnt.setBeneficiaryPhoneNbr(memInfo.substring(11, 21));
		ppclMembrSegmnt.setCountryWorkerPhoneNbr(memInfo.substring(21, 31));
		ppclMembrSegmnt.setHiqMailingDate(memInfo.substring(31, 39));
		ppclMembrSegmnt.setOhcLetterMailingDate(memInfo.substring(39, 47));
		ppclMembrSegmnt.setFormLetterMailingDate(memInfo.substring(47, 55));
		ppclMembrSegmnt.setIvdMemberId(memInfo.substring(55, 65));
		ppclMembrSegmnt.setFiller1(memInfo.substring(65, 71));
		ppclMembrSegmnt.setHiqFlag(Character.toString(memInfo.charAt(71)));
		ppclMembrSegmnt.setPendingOHC(Character.toString(memInfo.charAt(72)));
		ppclMembrSegmnt.setMedsCurrentDate(memInfo.substring(73, 79));
		ppclMembrSegmnt.setFiller2(memInfo.substring(79, 83));

		ppclMembrSegmnt.setRecordStatus(PPCLConstant.RECORD_STATUS_RECEIVED);
		// TODO update the received file ID from PPCL_Received_File_T
		ppclMembrSegmnt.setRcvdFileId(2l);

		long now = System.currentTimeMillis();
		Timestamp timestamp = new Timestamp(now);
		ppclMembrSegmnt.setInsertTimestamp(timestamp);
		ppclMembrSegmnt.setUpdateTimeStamp(timestamp);

		ppclMembrSegmnt.setInsertUser(DatabaseUtils.getDatabseUsername());
		ppclMembrSegmnt.setUpdateUser(DatabaseUtils.getDatabseUsername());
		
		benInfoRepo.save(ppclMembrSegmnt);
		entityManager.close();
		
		return ppclMembrSegmnt;
	}

	/**
	 * This method will fetch the OHC info from the given String, as per the
	 * HISDB-CALOPTIMA details provided, Segment is the only extra column as compared
	 * to HISDB details
	 * 
	 * @param memInfo
	 * @return
	 */

	@Transactional
	private List<PPCLHISDBCarrierStageDTO> processOHCSegment(PPCLHISDBBenIfoStageDTO benInfo, String ohcSegment) {
		List<PPCLHISDBCarrierStageDTO> ohcSegList = new ArrayList<>();
		PPCLHISDBCarrierStageDTO ppclHISDBCarrierStageDTO = null;
		String[] ohcDataArr = ohcSegment.split("(?<=\\G.{513})");
		entityManager.close();
		String regionCode = ApplicationProperties.getRegion();
		for (String ohcData : ohcDataArr) {
			ppclHISDBCarrierStageDTO = new PPCLHISDBCarrierStageDTO();
			ppclHISDBCarrierStageDTO.setRegionCode(regionCode);
			ppclHISDBCarrierStageDTO.setSegment(ohcData.substring(0, 2));
			ppclHISDBCarrierStageDTO.setCarrierCode(ohcData.substring(2, 6));
			ppclHISDBCarrierStageDTO.setpolicyNumber(ohcData.substring(6, 36));
			ppclHISDBCarrierStageDTO.setSegmentTyp(Character.toString(ohcData.charAt(36)));
			ppclHISDBCarrierStageDTO.setScopOfCoverage(ohcData.substring(37, 53));
			ppclHISDBCarrierStageDTO.setPolicyStartDate(ohcData.substring(53, 61));

			ppclHISDBCarrierStageDTO.setPolicyStopDate(ohcData.substring(61, 69));
			ppclHISDBCarrierStageDTO.setLastChangeDate(ohcData.substring(69, 77));
			ppclHISDBCarrierStageDTO.setSourceOfChange(ohcData.substring(77, 81));
			ppclHISDBCarrierStageDTO.setTransactionTyp(Character.toString(ohcData.charAt(81)));

			ppclHISDBCarrierStageDTO.setOperatorId(ohcData.substring(82, 85));
			ppclHISDBCarrierStageDTO.setFiller1(ohcData.substring(85, 90));
			ppclHISDBCarrierStageDTO.setAbsentParentInsuranceFlag(Character.toString(ohcData.charAt(90)));
			ppclHISDBCarrierStageDTO.setInsuranceStatusCode(Character.toString(ohcData.charAt(91)));
			ppclHISDBCarrierStageDTO.setRelationShipToPolicyHolder(Character.toString(ohcData.charAt(92)));

			ppclHISDBCarrierStageDTO.setDependentCoverageAvilable(Character.toString(ohcData.charAt(93)));
			ppclHISDBCarrierStageDTO.setIexSourceOfCoverage(Character.toString(ohcData.charAt(94)));
			ppclHISDBCarrierStageDTO.setTerminationReason(ohcData.substring(95, 97));
			ppclHISDBCarrierStageDTO.setFollowUpFlag(Character.toString(ohcData.charAt(97)));
			ppclHISDBCarrierStageDTO.setPolicyHolderSSN(ohcData.substring(98, 107));
			ppclHISDBCarrierStageDTO.setPolicyHolderLastNM(ohcData.substring(107, 122));
			ppclHISDBCarrierStageDTO.setPolicyHolderFirstNM(ohcData.substring(122, 132));
			ppclHISDBCarrierStageDTO.setPolicyHolderMiddleInitial(ohcData.substring(132, 133));
			ppclHISDBCarrierStageDTO.setPolicyHolderAddrLine1(ohcData.substring(133, 159));
			ppclHISDBCarrierStageDTO.setPolicyHolderAddrLine2(ohcData.substring(159, 185));

			ppclHISDBCarrierStageDTO.setPolicyHolderCityState(ohcData.substring(185, 205));
			ppclHISDBCarrierStageDTO.setPolicyHolderZipCD(ohcData.substring(205, 210));
			ppclHISDBCarrierStageDTO.setPolicyHolderZip4(ohcData.substring(210, 214));
			ppclHISDBCarrierStageDTO.setPolicyHolderPhoneNbr(ohcData.substring(214, 224));
			ppclHISDBCarrierStageDTO.setGroupEmployerName(ohcData.substring(224, 254));
			ppclHISDBCarrierStageDTO.setGroupEmployerNumber(ohcData.substring(254, 274));
			ppclHISDBCarrierStageDTO.setGroupEmployerAddrLine1(ohcData.substring(274, 300));
			ppclHISDBCarrierStageDTO.setGroupEmployerAddrLine2(ohcData.substring(300, 326));

			ppclHISDBCarrierStageDTO.setGroupEmployerCityState(ohcData.substring(326, 346));
			ppclHISDBCarrierStageDTO.setGroupEmployerZipCD(ohcData.substring(346, 351));
			ppclHISDBCarrierStageDTO.setGroupEmployerZip4(ohcData.substring(351, 355));
			ppclHISDBCarrierStageDTO.setGroupEmployerPhoneNbr(ohcData.substring(355, 365));

			ppclHISDBCarrierStageDTO.setUnionName(ohcData.substring(365, 395));
			ppclHISDBCarrierStageDTO.setUnionLocalNumber(ohcData.substring(395, 415));

			ppclHISDBCarrierStageDTO.setBountyAddDate(ohcData.substring(415, 423));
			ppclHISDBCarrierStageDTO.setBountyAddSource(ohcData.substring(423, 427));
			ppclHISDBCarrierStageDTO.setBountyAddCountyId(ohcData.substring(427, 441));
			ppclHISDBCarrierStageDTO.setBountyAddEligWorkerCD(ohcData.substring(441, 445));
			ppclHISDBCarrierStageDTO.setBountyAddDistrict(ohcData.substring(445, 448));
			ppclHISDBCarrierStageDTO.setBountyStatus(ohcData.substring(448, 449));
			ppclHISDBCarrierStageDTO.setPlanId(ohcData.substring(449, 452));
			ppclHISDBCarrierStageDTO.setTypeId(ohcData.substring(452, 454));
			ppclHISDBCarrierStageDTO.setFiller2(ohcData.substring(454));

			ppclHISDBCarrierStageDTO.setRcvdFileId(benInfo.getRcvdFileId());
			ppclHISDBCarrierStageDTO.setRcvdOhcBeninfoId(benInfo.getRcvdOhcBeninfoId());
			ppclHISDBCarrierStageDTO.setRecordStatus(benInfo.getRecordStatus());
			ppclHISDBCarrierStageDTO.setMedsId(benInfo.getMedsId());
			ppclHISDBCarrierStageDTO.setRegionCode(benInfo.getRegionCode());

			long now = System.currentTimeMillis();
			Timestamp timestamp = new Timestamp(now);
			ppclHISDBCarrierStageDTO.setInsertTimestamp(timestamp);
			ppclHISDBCarrierStageDTO.setUpdateTimeStamp(timestamp);

			// TODO update the user with actual data
			ppclHISDBCarrierStageDTO.setInsertUser(DatabaseUtils.getDatabseUsername());
			ppclHISDBCarrierStageDTO.setUpdateUser(DatabaseUtils.getDatabseUsername());

			// TODO update the received file id from PPCL_Received_File_T
			ppclHISDBCarrierStageDTO.setRcvdOhcCarrierId(5l);

			ohcSegList.add(ppclHISDBCarrierStageDTO);
		}
		try {
			ohcStageRepo.saveAll(ohcSegList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ohcSegList;
	}

	/**
	 * 
	 * This method will move the given file to desired location passed
	 * @param lzFile
	 * @param toPath
	 * @return
	 */
	private boolean moveFile(File lzFile, String toPath) {
		Path tempWork = null;
		try {
			String fileName = lzFile.getName();
			tempWork = Files.move(Paths.get(lzFile.getPath()), Paths.get(toPath.concat("\\").concat(fileName)),
					StandardCopyOption.REPLACE_EXISTING);

			if (tempWork != null) {
				logger.info("File renamed and moved successfully to : " + toPath);
			} else {
				logger.info("Failed to move the file");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return (tempWork != null);
	}
}
