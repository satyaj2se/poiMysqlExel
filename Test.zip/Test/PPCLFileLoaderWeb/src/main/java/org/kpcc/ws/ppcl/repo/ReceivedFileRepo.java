package org.kpcc.ws.ppcl.repo;

import org.kpcc.ws.ppcl.dto.PPCLRecievedFileDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface ReceivedFileRepo  extends JpaRepository<PPCLRecievedFileDTO,Long>{

}
