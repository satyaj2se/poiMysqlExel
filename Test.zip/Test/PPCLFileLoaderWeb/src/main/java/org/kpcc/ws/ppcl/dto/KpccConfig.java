package org.kpcc.ws.ppcl.dto;

public class KpccConfig {

	private String parameterName;
    private String parameterValue;
    private String selector;
    private String regionCode;
    private String application;
    private String domainGroup;
    private String activeFlag;
    private String description;

    public String getParameterName() {
        return parameterName;
    }
    public String getParameterValue() {
        return parameterValue;
    }
    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }
    public void setParameterValue(String parameterValue) {
        this.parameterValue = parameterValue;
    }

    public String getSelector() {
        return selector;
    }

    public void setSelector(String selector) {
        this.selector = selector;
    }
    
	public String getRegionCode() {
		return regionCode;
	}
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	public String getApplication() {
		return application;
	}
	public void setApplication(String application) {
		this.application = application;
	}
	public String getDomainGroup() {
		return domainGroup;
	}
	public void setDomainGroup(String domainGroup) {
		this.domainGroup = domainGroup;
	}
	public String getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
		return "PPCLConfigVO [regionCode=" + regionCode + ", application=" + application + ", domainGroup="
				+ domainGroup + ", selector=" + selector + ", parameterName=" + parameterName + ", parameterValue="
				+ parameterValue + ", activeFlag=" + activeFlag + ", description=" + description +  "]";
	}
    
}
