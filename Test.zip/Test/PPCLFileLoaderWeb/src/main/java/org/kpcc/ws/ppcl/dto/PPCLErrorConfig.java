package org.kpcc.ws.ppcl.dto;
public class PPCLErrorConfig {
	
	public PPCLErrorConfig() {		
	}	
	
	private String code;
	private String message;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	@Override
	public String toString() {
		return "BenefitsError [code=" + code + ", message=" + message + "]";
	}	
	
	
	
}
