package org.kpcc.ws.ppcl.app;

import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.kpcc.ws.ppcl.context.PPCLContextListner;
import org.kpcc.ws.ppcl.mvc.WebConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

public class ServletInitializer extends SpringBootServletInitializer implements WebApplicationInitializer{

private static Logger logger = Logger.getLogger(ServletInitializer.class.getName());
	
	public ServletInitializer(){
		super();
	}
	
	@Override
	public void onStartup(ServletContext ctx) throws ServletException {
		  AnnotationConfigWebApplicationContext webCtx = new AnnotationConfigWebApplicationContext();
		  webCtx.register(WebConfiguration.class);
		  webCtx.setServletContext(ctx);
		  logger.info("    PPCL Context Listener start    "+ctx);
    	  // Add Listener.
		  ctx.addListener(new PPCLContextListner());
		  
	}
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		logger.info("    PPCL Context Listener");
		return application.sources(PPCLFileLoaderApplication.class);
	}

}
