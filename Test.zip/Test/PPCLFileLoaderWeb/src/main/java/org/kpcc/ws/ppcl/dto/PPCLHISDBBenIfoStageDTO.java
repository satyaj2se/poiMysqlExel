package org.kpcc.ws.ppcl.dto;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

/*POJO class corresponding to the table PPCL_HISDB_BENINFO_STG_T*/

@Data
@Entity
@Table(name = "PPCL_HISDB_BENINFO_STG_T")
public class PPCLHISDBBenIfoStageDTO {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "RCVD_OHC_BENINFO_ID")
	Long rcvdOhcBeninfoId;
	/*
	 * Added ohcIndicatorCode
	 *  as a part of
	 *   HISDBLIKE file read
	 */
	@Column(name = "OHC_INDICATOR_CODE")
	String ohcIndicatorCode;
	
	//Add with log and FileName
	@Column(name = "LOG_ID")
	long logId;
	@Column(name = "FILE_NAME")
	String fileName;
	
	@Column(name = "RCVD_FILE_ID")
	Long rcvdFileId;
	@Column(name = "RECORD_STATUS")
	String recordStatus;
	@Column(name = "REGION_CODE")
	String regionCode;
	@Column(name = "MEDS_ID")
	String medsId;
	@Column(name = "NBR_OF_INSURANCE_SEGMENTS")
	String nbrOfInsuranceSegments;
	@Column(name = "BENEFICIARY_PHONE_NBR")
	String beneficiaryPhoneNbr;
	@Column(name = "COUNTRY_WORKER_PHONE_NBR")
	String countryWorkerPhoneNbr;
	@Column(name = "HIQ_MAILING_DATE")
	String hiqMailingDate;
	@Column(name = "OHC_LETTER_MAILING_DATE")
	String ohcLetterMailingDate;
	@Column(name = "FORM_LETTER_MAILING_DATE")
	String formLetterMailingDate;
	@Column(name = "IVD_MEMBER_ID")
	String ivdMemberId;
	@Column(name = "HIQ_FLAG")
	String hiqFlag;
	@Column(name = "PENDING_OHC")
	String pendingOHC;
	@Column(name = "MEDS_CURRENT_DATE")
	String medsCurrentDate;
	@Column(name = "FILLER1")
	String filler1;
	@Column(name = "FILLER2")
	String filler2;

	@Column(name = "INSERT_TIMESTAMP")
	Timestamp insertTimestamp;
	@Column(name = "INSERT_USER")
	String insertUser;
	@Column(name = "UPDATE_TIMESTAMP")
	Timestamp updateTimeStamp;
	@Column(name = "UPDATE_USER")
	String updateUser;
	
	@Column(name = "INSERT_PROCESS")
	String insertProcess;
	@Column(name = "INSERT_PROCESS_ID")
	Long insertProcessId;
	@Column(name = "UPDATE_PROCESS")
	String updateProcess;
	@Column(name = "UPDATE_PROCESS_ID")
	Long updateProcessId;

	public PPCLHISDBBenIfoStageDTO() {
	}

	public Long getRcvdOhcBeninfoId() {
		return rcvdOhcBeninfoId;
	}

	public void setRcvdOhcBeninfoId(Long rcvdOhcBeninfoId) {
		this.rcvdOhcBeninfoId = rcvdOhcBeninfoId;
	}

	public Long getRcvdFileId() {
		return rcvdFileId;
	}

	public void setRcvdFileId(Long rcvdFileId) {
		this.rcvdFileId = rcvdFileId;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getMedsId() {
		return medsId;
	}

	public void setMedsId(String medsId) {
		this.medsId = medsId;
	}

	public String getNbrOfInsuranceSegments() {
		return nbrOfInsuranceSegments;
	}

	public void setNbrOfInsuranceSegments(String nbrOfInsuranceSegments) {
		this.nbrOfInsuranceSegments = nbrOfInsuranceSegments;
	}

	public String getBeneficiaryPhoneNbr() {
		return beneficiaryPhoneNbr;
	}

	public void setBeneficiaryPhoneNbr(String beneficiaryPhoneNbr) {
		this.beneficiaryPhoneNbr = beneficiaryPhoneNbr;
	}

	public String getCountryWorkerPhoneNbr() {
		return countryWorkerPhoneNbr;
	}

	public void setCountryWorkerPhoneNbr(String countryWorkerPhoneNbr) {
		this.countryWorkerPhoneNbr = countryWorkerPhoneNbr;
	}

	public String getHiqMailingDate() {
		return hiqMailingDate;
	}

	public void setHiqMailingDate(String hiqMailingDate) {
		this.hiqMailingDate = hiqMailingDate;
	}

	public String getOhcLetterMailingDate() {
		return ohcLetterMailingDate;
	}

	public void setOhcLetterMailingDate(String ohcLetterMailingDate) {
		this.ohcLetterMailingDate = ohcLetterMailingDate;
	}

	public String getFormLetterMailingDate() {
		return formLetterMailingDate;
	}

	public void setFormLetterMailingDate(String formLetterMailingDate) {
		this.formLetterMailingDate = formLetterMailingDate;
	}

	public String getIvdMemberId() {
		return ivdMemberId;
	}

	public void setIvdMemberId(String ivdMemberId) {
		this.ivdMemberId = ivdMemberId;
	}

	public String getHiqFlag() {
		return hiqFlag;
	}

	public void setHiqFlag(String hiqFlag) {
		this.hiqFlag = hiqFlag;
	}

	public String getPendingOHC() {
		return pendingOHC;
	}

	public void setPendingOHC(String pendingOHC) {
		this.pendingOHC = pendingOHC;
	}

	public String getMedsCurrentDate() {
		return medsCurrentDate;
	}

	public void setMedsCurrentDate(String medsCurrentDate) {
		this.medsCurrentDate = medsCurrentDate;
	}

	public String getFiller1() {
		return filler1;
	}

	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}

	public String getFiller2() {
		return filler2;
	}

	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}

	public Timestamp getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Timestamp insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public String getInsertUser() {
		return insertUser;
	}

	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}

	public Timestamp getUpdateTimeStamp() {
		return updateTimeStamp;
	}

	public void setUpdateTimeStamp(Timestamp updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getInsertProcess() {
		return insertProcess;
	}

	public void setInsertProcess(String insertProcess) {
		this.insertProcess = insertProcess;
	}

	public Long getInsertProcessId() {
		return insertProcessId;
	}

	public void setInsertProcessId(Long insertProcessId) {
		this.insertProcessId = insertProcessId;
	}

	public String getUpdateProcess() {
		return updateProcess;
	}

	public void setUpdateProcess(String updateProcess) {
		this.updateProcess = updateProcess;
	}

	public Long getUpdateProcessId() {
		return updateProcessId;
	}

	public void setUpdateProcessId(Long updateProcessId) {
		this.updateProcessId = updateProcessId;
	}
	public String getOhcIndicatorCode() {
		return ohcIndicatorCode;
	}

	public void setOhcIndicatorCode(String ohcIndicatorCode) {
		this.ohcIndicatorCode = ohcIndicatorCode;
	}

	public long getLogId() {
		return logId;
	}

	public void setLogId(long logId) {
		this.logId = logId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}
