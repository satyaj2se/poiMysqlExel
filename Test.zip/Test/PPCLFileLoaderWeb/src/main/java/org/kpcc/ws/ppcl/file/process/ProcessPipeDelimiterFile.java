/**
 * 
 */
package org.kpcc.ws.ppcl.file.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.kpcc.ws.ppcl.constants.PPCLConstant;
import org.kpcc.ws.ppcl.dto.PPCLHISDBBenIfoStageDTO;
import org.kpcc.ws.ppcl.dto.PPCLPipeStageDTO;
import org.kpcc.ws.ppcl.exception.BusinessExceptionMessage;
import org.kpcc.ws.ppcl.properties.ApplicationProperties;
import org.kpcc.ws.ppcl.repo.PPCLPipeDelimterRepo;
import org.kpcc.ws.ppcl.utils.DataValidatorUtil;
import org.kpcc.ws.ppcl.utils.DatabaseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author S492749
 *
 */
@Component
public class ProcessPipeDelimiterFile 
{

	private static Logger logger = LogManager.getLogger(ProcessPipeDelimiterFile.class);
	
	
	@Autowired
	private PPCLPipeDelimterRepo pipeRepo;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	/**
	 * This method will process the PPCL data from the HISDB-Like Pipe Delimited file passed,
	 * @param lzMap
	 * @param lzFile
	 * @return
	 */
	public String processPipeDelimiterData(Map<String, String> lzMap, File lzFile)
	{
		logger.info("ProcessPipeDelimiterFile : HISDB-Like Pipe Delimited data processing initiated...");
		String status = "";

		if(lzFile != null) {
			List<String> lines = new ArrayList<>();
			List<PPCLPipeStageDTO> errorRec = new ArrayList<>();
			List<PPCLPipeStageDTO> validRec = new ArrayList<>();
			Map<Integer, String> headerMap = new HashMap<>();
			
			String workingPath = lzMap.get(PPCLConstant.LOADER_WORKING_PATH);
			String errorPath = lzMap.get(PPCLConstant.LOADER_ERROR_PATH);

	    	try (BufferedReader br = Files.newBufferedReader(Paths.get(lzFile.getPath()))) {
				lines = br.lines().collect(Collectors.toList());
				// read each line from the given file.
				if(CollectionUtils.isEmpty(lines)) {
					throw new BusinessExceptionMessage("No data available in the given file "+lzFile.getName());
				} 
				else {
					String headers = lines.get(0);
					int count = 0;
					for(String header : headers.split("|")) {
						headerMap.put(count, header);
						count++;
					}
					lines.stream().skip(0).forEach((str) -> {
						try {
							if(StringUtils.isBlank(str)) 
							{
								throw new BusinessExceptionMessage("Invalid data indentified");
							}
							else 
							{
								PPCLPipeStageDTO pipeDTO = processPipeData(headerMap, str);
								validRec.add(pipeDTO);
							}
						} catch(BusinessExceptionMessage be) {
							logger.error("Error occured while processing record");
						}
					});
					
					if(!validRec.isEmpty()) {
						pipeRepo.saveAll(validRec);
						status = "Success";
					}
					if(status.equalsIgnoreCase("Success")) {
						moveFile(lzFile, workingPath);
					} else {
						moveFile(lzFile, errorPath);
					}
				}
			} 
	    	catch (BusinessExceptionMessage be) {
				logger.error("Unable to process the HISDB pipe delimited data due to : "+be.getMessage());
				status = "Failed";
				moveFile(lzFile, errorPath);
			}
	    	catch (IOException ie) {
				logger.error("Error occured while processing the data : "+ie.getMessage());
				status = "Failed";
				moveFile(lzFile, errorPath);
			}
		}
		else {
			status = "Failed";
		}
		return status;
	}
	
	/**
	 * This method will fetch the claims info from the given String, as per the mappinf doc details provided
	 * @param headerMap
	 * @param claim
	 * @return
	 */
	@Transactional
	private PPCLPipeStageDTO processPipeData(Map<Integer, String> headerMap, String claim)
	{
		PPCLPipeStageDTO pipeDTO = null;
		try {
			if(!headerMap.isEmpty() && StringUtils.isNotBlank(claim))  {
				Map<String, Object> pipeMap = new HashMap<>();
				int count = 0;
				for(String str : claim.split("|")) {
					pipeMap.put(headerMap.get(count), str);
					count++;
				}
				ObjectMapper mapper = new ObjectMapper();
				pipeDTO = mapper.convertValue(pipeMap, PPCLPipeStageDTO.class);
				String regionCode = ApplicationProperties.getRegion();
				
				pipeDTO.setRegionCode(regionCode);
				pipeDTO.setRecordStatus(PPCLConstant.RECORD_STATUS_RECEIVED);
				//TODO update the received file ID from PPCL_Received_File_T
				pipeDTO.setRcvdFileId(2l);
				
				long now = System.currentTimeMillis();
		        Timestamp timestamp = new Timestamp(now);
		        pipeDTO.setInsertTimestamp(timestamp);
		        pipeDTO.setUpdateTimeStamp(timestamp);
				
		        pipeDTO.setInsertUser(DatabaseUtils.getDatabseUsername());
		        pipeDTO.setUpdateUser(DatabaseUtils.getDatabseUsername());
			}			
		} catch(Exception e) {
			logger.error("Unable to process the given data : "+e.getLocalizedMessage());
		}
		
		return pipeDTO;
	}
	
	private boolean moveFile(File lzFile, String toPath)
	{
		Path tempWork = null;
		try {
			String fileName = lzFile.getName();
			tempWork = Files.move(Paths.get(lzFile.getPath()), Paths.get(toPath.concat("\\").concat(fileName)), StandardCopyOption.REPLACE_EXISTING);

			if (tempWork != null) {
				logger.info("File renamed and moved successfully to : "+toPath);
			} else {
				logger.info("Failed to move the file");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return (tempWork != null);
	}


}
