package org.kpcc.ws.ppcl.file.process;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.kpcc.ws.ppcl.constants.PPCLConstant;
import org.kpcc.ws.ppcl.dto.PPCLHISDBBenIfoStageDTO;
import org.kpcc.ws.ppcl.dto.PPCLHISDBCarrierStageDTO;
import org.kpcc.ws.ppcl.dto.PPCLTransformedOHCRecDTO;
import org.kpcc.ws.ppcl.properties.ApplicationProperties;
import org.kpcc.ws.ppcl.repo.PPCLHISDBBenInfoStageRepo;
import org.kpcc.ws.ppcl.repo.PPCLHISDBCarrierRepo;
import org.kpcc.ws.ppcl.repo.PPCLTransformedOHCRecRepo;
import org.kpcc.ws.ppcl.service.KPCCDBLookUpService;
import org.kpcc.ws.ppcl.service.MEPDRMemberLookUpService;
import org.kpcc.ws.ppcl.utils.DataValidatorUtil;
import org.kpcc.ws.ppcl.utils.DatabaseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author S492749
 *
 */
@Component
public class TransformHISDBToOHC {

	private static Logger logger = LogManager.getLogger(TransformHISDBToOHC.class);

	@Autowired
	private PPCLHISDBBenInfoStageRepo benInfoRepo;

	@Autowired
	private PPCLHISDBCarrierRepo ohcStageRepo;

	@Autowired
	private PPCLTransformedOHCRecRepo ohcRecRepo;

	@Autowired
	MEPDRMemberLookUpService memLookUpService;

	@Autowired
	KPCCDBLookUpService kpccLookUpService;

	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * This method reads the data from the staging tables. This is then filtered ,
	 * augmented and saved to transformation table
	 * 
	 * @param fcMap
	 * @return
	 */
	@Transactional
	public String transFormHHISDBtoOHC(Map<String, String> fcMap) {
		List<PPCLHISDBBenIfoStageDTO> memInfoList = new ArrayList<>();
		List<PPCLHISDBCarrierStageDTO> segInfoList = null;
		String status = "";
		String regionCode = ApplicationProperties.getRegion();
		try {
			logger.info("TransformHISDBToOHC: transformation of HISDB data from staging initiated...");
			memInfoList = benInfoRepo.findAllBystatus(PPCLConstant.RECORD_STATUS_RECEIVED);

			Map<String, String> mepderInfo = null;
			Map<String, String> kpccInfo = null;
			PPCLTransformedOHCRecDTO ohcRec = null;
			List<PPCLTransformedOHCRecDTO> ohcRecList = new ArrayList<>();

			for (PPCLHISDBBenIfoStageDTO benInfo : memInfoList) {
				if (DataValidatorUtil.isBenInfoValid(benInfo)) {
					segInfoList = ohcStageRepo.findAllBystatusAndOHCBenInfoID(PPCLConstant.RECORD_STATUS_RECEIVED,
							benInfo.getRcvdOhcBeninfoId());
					// TODO remove the hardcoded ssn and use the below once MEPDR is active
					mepderInfo = memLookUpService.getMemberDetails("134279393");
					// mepderInfo = memLookUpService.getMemberDetails(benInfo.getMedsId());
					kpccInfo = kpccLookUpService.getMemberDetails(mepderInfo.get("MBR_MRN"));

					// filter the staging list.
					List<PPCLHISDBCarrierStageDTO> newSegInfoList = filterList(segInfoList, fcMap);
					if (!newSegInfoList.isEmpty()) {
						for (PPCLHISDBCarrierStageDTO segRec : newSegInfoList) {
							if (DataValidatorUtil.isCarrierStageValid(segRec)) {
								ohcRec = new PPCLTransformedOHCRecDTO();
								/** Augment member info to transformation */
								ohcRec.setRcvdOhcBeninfoId(benInfo.getRcvdOhcBeninfoId());
								// missing record status column in transformation rec table
								ohcRec.setMbrMRN(mepderInfo.get("MBR_MRN"));
								ohcRec.setMbrSSN(mepderInfo.get("MBR_SSN"));
								ohcRec.setNbrOfInsuranceSegments(benInfo.getNbrOfInsuranceSegments());
								ohcRec.setBeneficiaryPhoneNBR(benInfo.getBeneficiaryPhoneNbr());
								ohcRec.setPendingOHC(benInfo.getPendingOHC());
								// ohc indicator code is part of HISDB-HPSM file read
								ohcRec.setOhcIndicatorCode(benInfo.getOhcIndicatorCode());
								ohcRec.setRegionCode(regionCode);

								/** Augment Segment info */
								// segment is part of HISDBCALOPTIMA file read
								ohcRec.setSegId(segRec.getSegment());
								ohcRec.setSegCarrierCode(segRec.getCarrierCode());
								ohcRec.setSegPolicyNumber(segRec.getpolicyNumber());
								ohcRec.setSegSegmentType(segRec.getSegmentTyp());
								ohcRec.setSegScopeOfCoverage(segRec.getScopOfCoverage());
								ohcRec.setSegPolicyStartDate(segRec.getPolicyStartDate());
								ohcRec.setSegPolicyStopDate(segRec.getPolicyStopDate());
								ohcRec.setSegLastChangeDate(segRec.getLastChangeDate());
								ohcRec.setSegTransactionType(segRec.getTransactionTyp());
								ohcRec.setSegAbsentParentInsuranceFlag(segRec.getAbsentParentInsuranceFlag());
								ohcRec.setSegInsuranceStatusCode(segRec.getInsuranceStatusCode());
								ohcRec.setSegRelationShipToPolicyHolder(segRec.getRelationShipToPolicyHolder());
								ohcRec.setSegDependentCoverageAvilable(segRec.getDependentCoverageAvilable());
								ohcRec.setSegIEXSourceOfCoverage(segRec.getIexSourceOfCoverage());
								ohcRec.setSegTerminationReason(segRec.getTerminationReason());

								ohcRec.setSegPolicyHolderSSN(segRec.getPolicyHolderSSN());
								ohcRec.setSegPolicyHolderLastNM(segRec.getPolicyHolderLastNM());
								ohcRec.setSegPolicyHolderFirstNM(segRec.getPolicyHolderFirstNM());
								ohcRec.setSegPolicyHolderMiddleInit(segRec.getPolicyHolderMiddleInitial());
								ohcRec.setSegPolicyHolderAddrLine1(segRec.getPolicyHolderAddrLine1());
								ohcRec.setSegPolicyHolderAddrLine2(segRec.getPolicyHolderAddrLine2());
								ohcRec.setSegPolicyHolderAddrCityState(segRec.getPolicyHolderCityState());
								ohcRec.setSegPolicyHolderZipCD(segRec.getPolicyHolderZipCD());
								ohcRec.setSegPolicyHolderZip4(segRec.getPolicyHolderZip4());
								ohcRec.setSegPolicyHolderPhoneNBR(segRec.getPolicyHolderPhoneNbr());

								ohcRec.setSegGrpEmployerNM(segRec.getGroupEmployerName());
								ohcRec.setSegGrpEmployerNBR(segRec.getGroupEmployerNumber());
								ohcRec.setSegGrpEmployerAddrLine1(segRec.getGroupEmployerAddrLine1());
								ohcRec.setSegGrpEmployerAddrLine2(segRec.getGroupEmployerAddrLine2());
								ohcRec.setSegGrpEmployerCityState(segRec.getGroupEmployerCityState());
								ohcRec.setSegGrpEmployerZipCode(segRec.getGroupEmployerZipCD());
								ohcRec.setSegGrpEmployerZip4(segRec.getGroupEmployerZip4());
								ohcRec.setSegGrpEmployerPhoneNumber(segRec.getGroupEmployerPhoneNbr());

								ohcRec.setSegPlanId(segRec.getPlanId());
								ohcRec.setRecordStatus(PPCLConstant.RECORD_STATUS_EXTRACT);

								long now = System.currentTimeMillis();
								Timestamp timestamp = new Timestamp(now);
								ohcRec.setInsertTimestamp(timestamp);
								ohcRec.setUpdateTimeStamp(timestamp);
								ohcRec.setInsertUser(DatabaseUtils.getDatabseUsername());
								ohcRec.setUpdateUser(DatabaseUtils.getDatabseUsername());

								ohcRecList.add(ohcRec);
								ohcRecRepo.save(ohcRec);

								// TODO update the status with defined values
								segRec.setRecordStatus(PPCLConstant.RECORD_STATUS_EXTRACT);
								ohcStageRepo.save(segRec);
								// TODO update the status with defined values
								benInfo.setRecordStatus(PPCLConstant.RECORD_STATUS_EXTRACT);
								benInfoRepo.save(benInfo);

							} else {
								segRec.setRecordStatus(PPCLConstant.RECORD_STATUS_ERROR);
								ohcStageRepo.save(segRec);
								status = "Require fields are missing";
							}
						}
						status = "Success";
					} else {
						logger.info("No records left to transform.");
						status = "No records found";
					}
				} else {
					benInfo.setRecordStatus(PPCLConstant.RECORD_STATUS_ERROR);
					benInfoRepo.save(benInfo);
					status = "Require fields are missing";
				}

			}
		} catch (Exception e) {
			logger.error("Failed to transform the staging records.");
			status = "Failed";
		}
		return status;
	}

	/**
	 * This method will filter the given list based on the filter config provided.
	 * 
	 * @param segInfoList
	 * @param fcMap
	 */
	private List<PPCLHISDBCarrierStageDTO> filterList(List<PPCLHISDBCarrierStageDTO> segInfoList,
			Map<String, String> fcMap) {
		List<PPCLHISDBCarrierStageDTO> newSegInfoList = new ArrayList<>();
		if (!fcMap.isEmpty() && !segInfoList.isEmpty()) {
			String carrierCode = fcMap.get(PPCLConstant.PPCL_CARRIER_CODE_FILTER_KEY);
			String coverage = fcMap.get(PPCLConstant.PPCL_SCOPE_OF_COVERAGE_FILTER_KEY);
			// TODO consider policy stop date
			newSegInfoList = segInfoList.stream().filter(s -> !carrierCode.contains(s.getCarrierCode()))
					.filter(s -> coverage.contains(s.getScopOfCoverage())).collect(Collectors.toList());
		}
		return newSegInfoList;
	}
}
