package org.kpcc.ws.ppcl.exception;

public class SystemCriticalException extends RuntimeException{
	  public SystemCriticalException(String msg){
	        super(msg);
	    }
	    public SystemCriticalException(Exception e) {super(e);}
}
