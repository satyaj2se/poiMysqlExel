
package org.kpcc.ws.ppcl.dto;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/*POJO class corresponding to the table PPCL_FILE_ERROR_T*/

@Data
@Table(name = "PPCL_FILE_ERROR_T")
@Entity
public class PPCLFileErrorDTO {

	@Id
//	@SequenceGenerator(name = "partner_sequence", sequenceName = "partner_sequence", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "FILE_ERROR_ID")
	Long fileErrorId;
	@Column(name = "RCVD_FILE_ID")
	Long rcvdFileId;
	@Column(name = "PARTNER_ID")
	Long partnerId;
	@Column(name = "PROCESS_ID")
	Long processId;
	
	@Column(name = "REGION_CODE")
	String regionCode;
	@Column(name = "PROCESS_NAME")
	String processName;
	@Column(name = "MESSAGE")
	String message;

	@Column(name = "INSERT_TIMESTAMP")
	Timestamp insertTimestamp;
	@Column(name = "INSERT_USER")
	String insertUser;
	@Column(name = "UPDATE_TIMESTAMP")
	Timestamp updateTimeStamp;
	@Column(name = "UPDATE_USER")
	String updateUser;
	
	@Column(name = "INSERT_PROCESS")
	String insertProcess;
	@Column(name = "INSERT_PROCESS_ID")
	Long insertProcessId;
	@Column(name = "UPDATE_PROCESS")
	String updateProcess;
	@Column(name = "UPDATE_PROCESS_ID")
	Long updateProcessId;

	public Long getFileErrorId() {
		return fileErrorId;
	}
	public void setFileErrorId(Long fileErrorId) {
		this.fileErrorId = fileErrorId;
	}
	public Long getRcvdFileId() {
		return rcvdFileId;
	}
	public void setRcvdFileId(Long rcvdFileId) {
		this.rcvdFileId = rcvdFileId;
	}
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public Long getProcessId() {
		return processId;
	}
	public void setProcessId(Long processId) {
		this.processId = processId;
	}
	public String getRegionCode() {
		return regionCode;
	}
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Timestamp getInsertTimestamp() {
		return insertTimestamp;
	}
	public void setInsertTimestamp(Timestamp insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}
	public String getInsertUser() {
		return insertUser;
	}
	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}
	public Timestamp getUpdateTimeStamp() {
		return updateTimeStamp;
	}
	public void setUpdateTimeStamp(Timestamp updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getInsertProcess() {
		return insertProcess;
	}
	public void setInsertProcess(String insertProcess) {
		this.insertProcess = insertProcess;
	}
	public Long getInsertProcessId() {
		return insertProcessId;
	}
	public void setInsertProcessId(Long insertProcessId) {
		this.insertProcessId = insertProcessId;
	}
	public String getUpdateProcess() {
		return updateProcess;
	}
	public void setUpdateProcess(String updateProcess) {
		this.updateProcess = updateProcess;
	}
	public Long getUpdateProcessId() {
		return updateProcessId;
	}
	public void setUpdateProcessId(Long updateProcessId) {
		this.updateProcessId = updateProcessId;
	}
	
	@Override
	public String toString() {
		return "PPCLFileErrorDTO [fileErrorId=" + fileErrorId + ", rcvdFileId=" + rcvdFileId + ", partnerId="
				+ partnerId + ", processId=" + processId + ", regionCode=" + regionCode + ", processName=" + processName
				+ ", message=" + message + ", insertTimestamp=" + insertTimestamp + ", insertUser=" + insertUser
				+ ", updateTimeStamp=" + updateTimeStamp + ", updateUser=" + updateUser + ", insertProcess="
				+ insertProcess + ", insertProcessId=" + insertProcessId + ", updateProcess=" + updateProcess
				+ ", updateProcessId=" + updateProcessId + "]";
	}

}
