package org.kpcc.ws.ppcl.constants;

public class PPCLServiceConstant {

	public static final String KPHC_INVALID_USERID_FAULTCODE = "cache.security.invalidUserId-IdType";
	public static final String KPHC_INACTIVE_USERID_FAULTCODE = "cache.security.inactiveUserId";
	public static final String KPHC_HIDDEN_USERID_FAULTCODE = "cache.security.hiddenUserId";
	public static final String KPHC_INVALID_PATIENTID_FAULTCODE = "cache.parameter.invalidPatientId-IdType";
	public static final String KPHC_INVALID_PATIENTIDTYPE_FAULTCODE = "cache.parameter.invalidPatientIdType";
	
	public static final String EPIC_NO_PATIENT_FOUND = "NO-PATIENT-FOUND";
	public static final String INVALID_MRN = "INVALID_MRN";
	public static final String INVALID_AS_OF_DATE = "INVALID_AS_OF_DATE";
	public static final String CONFIGURATION_EXCEPTION = "CONFIGURATION_EXCEPTION";
	
	public static final String COMP_DATE_FORMAT = "MM-dd-yyyy";
	public static final String EPIC_SERVICE_DATE_FORMAT = "MM/dd/yyyy";
	public static final String ACCUMULATE_BY_PATIENT = "Patient";
	public static final String ACCUMULATE_BY_ACCOUNT = "Account";
	public static final String PERF_LOGGER   = "perf";
	public static final String CUT_OFF_DATE   = "01-01-2000";
	public static final String REQUEST_DATE_FORMAT = "mm-dd-yyyy";
	public static final String CVG_DEPLOYMENT_ID="CVG_DEPLOYMENT_ID";
	public static final String CVG_WS_ENDPOINT_URL="CVG_WS_ENDPOINT_URL";
	public static final String CVG_MRN_TYPE="CVG_MRN_TYPE";
	public static final String CVG_WS_PASSWORD="DATAPOWER_PASSWORD";
	public static final String CVG_WS_USERNAME="DATAPOWER_USERNAME";
	public static final String MRN_VALIDATOR="MRN_VALIDATOR";
	public static final String VALID_REGION_LIST="VALID_REGION_LIST";
	
	public static final String REGION_CODE ="REGION_CODE";
	public static final String SECURITY_HEADER = "CVG_SECURITY_HEADER";
	public static final String MBI_WS_ENDPOINT_URL = "MBI_WS_ENDPOINT_URL";
	public static final String CVG_MARSHALL_CLASS = "CVG_MARSHALL_CLASS";
	public static final String HTTP_CONNECTION_TIME_OUT = "HTTP_CONNECTION_TIME_OUT";
	public static final String HTTP_READ_TIME_OUT = "HTTP_READ_TIME_OUT";
	public static final String ONE = "1";
	public static final String ZERO = "0";

}