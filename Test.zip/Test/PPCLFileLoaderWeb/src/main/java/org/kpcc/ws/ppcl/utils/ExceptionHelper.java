package org.kpcc.ws.ppcl.utils;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.kpcc.ws.ppcl.vo.PPCLError;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

@Component
public class ExceptionHelper {
	private static final Logger LOGGER = LogManager.getLogger(ExceptionHelper.class);
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public PPCLError errors;

	/**
	 * Creates XML gregorian calendar with current date and time
	 * 
	 * @return XMLGregorianCalendar
	 */
	public XMLGregorianCalendar getCurrentTime() {
		GregorianCalendar gregorianCal = new GregorianCalendar();
		XMLGregorianCalendar xmlGregCal = null;
		try {
			xmlGregCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCal);
		} catch (Exception ex) {
			LOGGER.error("Exception Occured while creating gregorian calendar", ex);
		}
		return xmlGregCal;
	}

	public PPCLError getErrors() {
		return errors;
	}

	public void setErrors(PPCLError errors) {
		this.errors = errors;
	}
}
