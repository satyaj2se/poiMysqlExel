/**
 * 
 */
package org.kpcc.ws.ppcl.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.commons.codec.binary.Base64;


/**
 * 
 *
 */
public class DateUtil {
    /**
     * This class won't provide any instance members, 
     * so no need to instantiate the class.
     */
	private DateUtil(){
		
	}
	
	/**
	 * get Date and time
	 * 
	 * @param format
	 * @param cal
	 * 
	 * @return String
	 */
	public static String getDateTime(String format, Calendar cal) {
		
		if(format == null || cal == null) {
			return null;
		}
		DateFormat df = new SimpleDateFormat(format);
		df.setLenient(false);
		return df.format(cal.getTime());
	}
	
	/**
	 * get Date and time
	 * 
	 * @param format
	 * @param cal
	 * 
	 * @return String
	 */
	public static String getMBIDateTime(String format, String cal) {
		
		if(format == null || cal == null) {
			return null;
		}
		DateFormat df = new SimpleDateFormat(format);
		return df.format(cal);
	}

	/**
	 * Converts String to Calendar
	 * @param format
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static Calendar stringToCalendar(String format, String date) throws ParseException {
		
		if(format == null || date == null){
			return null;
		}
		
		DateFormat df = new SimpleDateFormat(format);
		df.setLenient(false);
		Calendar cal  = Calendar.getInstance();
		cal.setTime(df.parse(date));
		return cal;
	}
	/**
	 * Decodes given encoded value.
	 * 
	 * @param encryptedPass
	 * @return
	 * @throws Exception
	 */
	public static String getDecode(String encryptedPass) {
		if(encryptedPass == null || encryptedPass.length() == 0) {
			return null;
		}
		
        String returnVal = null;
        byte[] bytes = encryptedPass.getBytes();
        byte[] decodeBytes = Base64.decodeBase64(bytes);
        returnVal = new String(decodeBytes);
        return returnVal;
    } 
	
	/**
	 * Returns current date without time.
	 * 
	 * @return
	 */
	public static Calendar getCurrentDate() {
		
		Calendar cal = Calendar.getInstance();
		cal.clear(Calendar.HOUR);
		cal.clear(Calendar.HOUR_OF_DAY);
		cal.clear(Calendar.AM_PM);
		cal.clear(Calendar.MINUTE);
		cal.clear(Calendar.SECOND);
		cal.clear(Calendar.MILLISECOND);

		return cal;
	}
}
