package org.kpcc.ws.ppcl.repo;


import java.util.List;

import org.kpcc.ws.ppcl.dto.PPCLHISDBCarrierStageDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public interface PPCLHISDBCarrierRepo extends JpaRepository<PPCLHISDBCarrierStageDTO,Long>  {

	@Query(value="SELECT * FROM PPCL_HISDB_CARRIER_STG_T WHERE RECORD_STATUS = ? AND RCVD_OHC_BENINFO_ID = ?", nativeQuery = true)
	public List<PPCLHISDBCarrierStageDTO> findAllBystatusAndOHCBenInfoID(String status, Long benInfoId);
}
