/**
 * 
 */
package org.kpcc.ws.ppcl.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.kpcc.ws.ppcl.service.FileLoaderServiceImpl;
import org.kpcc.ws.ppcl.vo.PPCLError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Controller class to trigger EndPointUrl for the application
 * @author S492749
 *
 */
@Api(value = "PPCL", description = "Rest Api", tags = { "PPCLDetails" })
@RestController
public class PPCLFileLoaderRestController {

	private static final Logger LOGGER = LogManager.getLogger(PPCLFileLoaderRestController.class);
	
	@Autowired
	FileLoaderServiceImpl fls;

	@ApiOperation(value = "Servie Availaibility status ", response = String.class,tags = {"PPCLDetails"})
	@GetMapping("/getStatus/v1")
	public String isPPCLLive() {
		return String.format("PPCL Rest Service available- Date:%s , Time:%s", LocalDate.now().toString(),
				LocalTime.now().toString());
	}
	
	@GetMapping("/getLZ")
	public Map<String, String> getCount() {
		return fls.getLZFromConfig();
	}
	
	@ApiOperation(value = "Process HISDB Files from Plan partners ", tags = {"PPCLDetails"})
	@ApiResponses(value = {
	            @ApiResponse(code = 200, message = "Successfully populate the Benefit details",response = String.class),
	            @ApiResponse(code = 401, message = "You are not authorized to view the resource",response = PPCLError.class),
	            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden",response = PPCLError.class),
	            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found",response = PPCLError.class),
	            @ApiResponse(code = 500, message = "Application failed to process the request",response = PPCLError.class),
	            @ApiResponse(code = 1000, message = "1000 series for BCS Validation error",response = PPCLError.class),
	            @ApiResponse(code = 2000, message = "2000 series for Tapstry Business and system error ",response = PPCLError.class),
	            @ApiResponse(code = 3000, message = "3000 series for MBI2.0 Business and system error ",response = PPCLError.class)
	            
	    })
	@GetMapping("/processPPFileFromLZ")
	public String processPPFileFromLZ() {
		return fls.processPPFileFromLZ();
	}
	
	@ApiOperation(value = "transform HISDB data from staging to OHC format ", tags = {"PPCLDetails"})
	@ApiResponses(value = {
	            @ApiResponse(code = 200, message = "Successfully populate the Benefit details",response = String.class),
	            @ApiResponse(code = 401, message = "You are not authorized to view the resource",response = PPCLError.class),
	            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden",response = PPCLError.class),
	            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found",response = PPCLError.class),
	            @ApiResponse(code = 500, message = "Application failed to process the request",response = PPCLError.class),
	            @ApiResponse(code = 1000, message = "1000 series for BCS Validation error",response = PPCLError.class),
	            @ApiResponse(code = 2000, message = "2000 series for Tapstry Business and system error ",response = PPCLError.class),
	            @ApiResponse(code = 3000, message = "3000 series for MBI2.0 Business and system error ",response = PPCLError.class)
	            
	    })
	@GetMapping("/transformHISDBtoOHC")
	public String transformHISDBtoOHC() {
		return fls.transformHISDBtoOHC();
	}
}
