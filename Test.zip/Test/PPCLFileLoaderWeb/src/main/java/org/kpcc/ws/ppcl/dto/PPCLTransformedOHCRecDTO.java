package org.kpcc.ws.ppcl.dto;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Table(name = "PPCL_TRANSFORMED_OHC_REC_T")
@Entity
public class PPCLTransformedOHCRecDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name="TRANSFORMED_OHC_REC_ID")
	Long transformedOHCRecId;
	@Column(name="TRANSFORMED_OHC_FILE_ID")
	Long transformedOHCFileId;
	@Column(name="RCVD_OHC_BENINFO_ID")
	Long rcvdOhcBeninfoId;
	@Column(name="MBR_MRN")
	String mbrMRN;
	@Column(name="OHC_INDICATOR_CODE")
	String ohcIndicatorCode;
	@Column(name="MBR_SSN")
	String mbrSSN;
	@Column(name="MBR_MEDICAID_ID")
	String mbrMedicaidId;
	@Column(name="MBR_RGN")
	String mbrRGN;
	@Column(name="MBR_PLAN_NM")
	String mbrPlanNM;
	@Column(name="MBR_GROUP_NUMBER")
	String mbrGroupNumber;
	@Column(name="MBR_MBI")
	String mbrMBI;
	@Column(name="MBR_FIRST_NM")
	String mbrFirstNM;
	@Column(name="MBR_LAST_NM")
	String mbrLastNM;
	@Column(name="MBR_MIDDLE_NM")
	String mbrMiddileNM;
	@Column(name="MBR_DOB")
	String mbrDOB;
	@Column(name="MBR_RESIDENCY_STR_ADDR_NM")
	String mbrResidencyStrAddrNM;
	@Column(name="MBR_RESIDENCY_STR_ADDR2_NM")
	String mbrResidencyStrAddr2NM;
	@Column(name="MBR_RESIDENCY_CITY_NM")
	String mbrResidencyCityNM;
	@Column(name="MBR_RESIDENCY_ST_NM")
	String mbrResidencyStNM;
	@Column(name="MBR_RESIDENCY_ZIP_CD")
	String mbrResidencyZipCD;
	@Column(name="MBR_CONTACT_NBR")
	String mbrContactNBR;
	@Column(name="NBR_OF_INSURANCE_SEGMENTS")
	String nbrOfInsuranceSegments;
	@Column(name="BENEFICIARY_PHONE_NBR")
	String beneficiaryPhoneNBR;
	@Column(name="PENDING_OHC")
	String pendingOHC;
	@Column(name="SEGID")
	String segId;
	@Column(name="SEG_CARRIER_CODE")
	String segCarrierCode;
	@Column(name="SEG_POLICY_NUMBER")
	String segPolicyNumber;
	@Column(name="SEG_SEGMENT_TYPE")
	String segSegmentType;
	@Column(name="SEG_SCOPE_OF_COVRAGE")
	String segScopeOfCoverage;
	@Column(name="SEG_POLICY_START_DATE")
	String segPolicyStartDate;
	@Column(name="SEG_POLICY_STOP_DATE")
	String segPolicyStopDate;
	@Column(name="SEG_LAST_CHANGE_DATE")
	String segLastChangeDate;
	@Column(name="SEG_TRANSACTION_TYPE")
	String segTransactionType;
	@Column(name="SEG_ABSENT_PARENT_INSURANCE_FLAG")
	String segAbsentParentInsuranceFlag;
	@Column(name="SEG_INSURANCE_STATUS_CODE")
	String segInsuranceStatusCode;
	@Column(name="SEG_RELATIONSHIP_TO_POLICY_HOLDER")
	String segRelationShipToPolicyHolder;
	@Column(name="SEG_DEPENDENT_COVERAGE_AVILABLE")
	String segDependentCoverageAvilable;
	@Column(name="SEG_IEX_SOURCE_OF_COVERAGE")
	String segIEXSourceOfCoverage;
	@Column(name="SEG_TERMINATION_REASON")
	String segTerminationReason;
	@Column(name="SEG_POLICY_HOLDER_SSN")
	String segPolicyHolderSSN;
	@Column(name="SEG_POLICY_HOLDER_LAST_NM")
	String segPolicyHolderLastNM;
	@Column(name="SEG_POLICY_HOLDER_FIRST_NM")
	String segPolicyHolderFirstNM;
	@Column(name="SEG_POLICY_HOLDER_MIDDLE_INITIAL")
	String segPolicyHolderMiddleInit;
	@Column(name="SEG_POLICY_HOLDER_ADDR_LINE1")
	String segPolicyHolderAddrLine1;
	@Column(name="SEG_POLICY_HOLDER_ADDR_LINE2")
	String segPolicyHolderAddrLine2;
	@Column(name="SEG_POLICY_HOLDER_CITY_STATE")
	String segPolicyHolderAddrCityState;
	@Column(name="SEG_POLICY_HOLDER_ZIP_CD")
	String segPolicyHolderZipCD;
	@Column(name="SEG_POLICY_HOLDER_ZIP4")
	String segPolicyHolderZip4;
	@Column(name="SEG_POLICY_HOLDER_PHONE_NBR")
	String segPolicyHolderPhoneNBR;
	@Column(name="SEG_GRP_EMPLOYER_NM")
	String segGrpEmployerNM;
	@Column(name="SEG_GRP_EMPLOYER_NBR")
	String segGrpEmployerNBR;
	@Column(name="SEG_GRP_EMPLOYER_ADDR_LINE1")
	String segGrpEmployerAddrLine1;
	@Column(name="SEG_GRP_EMPLOYER_ADDR_LINE2")
	String segGrpEmployerAddrLine2;
	@Column(name="SEG_GRP_EMPLOYER_CITY_STATE")
	String segGrpEmployerCityState;
	@Column(name="SEG_GRP_EMPLOYER_ZIP_CODE")
	String segGrpEmployerZipCode;
	@Column(name="SEG_GRP_EMPLOYER_ZIP4")
	String segGrpEmployerZip4;
	@Column(name="SEG_GRP_EMPLOYER_PHONE_NUMBER")
	String segGrpEmployerPhoneNumber;
	@Column(name="SEG_PLAN_ID")
	String segPlanId;
	@Column(name="HOME_INSTANCE")
	String homeInstance;
	@Column(name = "REGION_CODE")
	String regionCode;
	@Column(name = "RECORD_STATUS")
	String recordStatus;

	@Column(name = "INSERT_TIMESTAMP")
	Timestamp insertTimestamp;
	@Column(name = "INSERT_USER")
	String insertUser;
	@Column(name = "UPDATE_TIMESTAMP")
	Timestamp updateTimeStamp;
	@Column(name = "UPDATE_USER")
	String updateUser;
	
	@Column(name = "INSERT_PROCESS")
	String insertProcess;
	@Column(name = "INSERT_PROCESS_ID")
	Long insertProcessId;
	@Column(name = "UPDATE_PROCESS")
	String updateProcess;
	@Column(name = "UPDATE_PROCESS_ID")
	Long updateProcessId;

	public Long getTransformedOHCRecId() {
		return transformedOHCRecId;
	}
	public void setTransformedOHCRecId(Long transformedOHCRecId) {
		this.transformedOHCRecId = transformedOHCRecId;
	}
	public Long getTransformedOHCFileId() {
		return transformedOHCFileId;
	}
	public void setTransformedOHCFileId(Long transformedOHCFileId) {
		this.transformedOHCFileId = transformedOHCFileId;
	}
	public Long getRcvdOhcBeninfoId() {
		return rcvdOhcBeninfoId;
	}
	public void setRcvdOhcBeninfoId(Long rcvdOhcBeninfoId) {
		this.rcvdOhcBeninfoId = rcvdOhcBeninfoId;
	}
	public String getMbrMRN() {
		return mbrMRN;
	}
	public void setMbrMRN(String mbrMRN) {
		this.mbrMRN = mbrMRN;
	}
	public String getOhcIndicatorCode() {
		return ohcIndicatorCode;
	}
	public void setOhcIndicatorCode(String ohcIndicatorCode) {
		this.ohcIndicatorCode = ohcIndicatorCode;
	}
	public String getMbrSSN() {
		return mbrSSN;
	}
	public void setMbrSSN(String mbrSSN) {
		this.mbrSSN = mbrSSN;
	}
	public String getMbrMedicaidId() {
		return mbrMedicaidId;
	}
	public void setMbrMedicaidId(String mbrMedicaidId) {
		this.mbrMedicaidId = mbrMedicaidId;
	}
	public String getMbrRGN() {
		return mbrRGN;
	}
	public void setMbrRGN(String mbrRGN) {
		this.mbrRGN = mbrRGN;
	}
	public String getMbrPlanNM() {
		return mbrPlanNM;
	}
	public void setMbrPlanNM(String mbrPlanNM) {
		this.mbrPlanNM = mbrPlanNM;
	}
	public String getMbrGroupNumber() {
		return mbrGroupNumber;
	}
	public void setMbrGroupNumber(String mbrGroupNumber) {
		this.mbrGroupNumber = mbrGroupNumber;
	}
	public String getMbrMBI() {
		return mbrMBI;
	}
	public void setMbrMBI(String mbrMBI) {
		this.mbrMBI = mbrMBI;
	}
	public String getMbrFirstNM() {
		return mbrFirstNM;
	}
	public void setMbrFirstNM(String mbrFirstNM) {
		this.mbrFirstNM = mbrFirstNM;
	}
	public String getMbrLastNM() {
		return mbrLastNM;
	}
	public void setMbrLastNM(String mbrLastNM) {
		this.mbrLastNM = mbrLastNM;
	}
	public String getMbrMiddileNM() {
		return mbrMiddileNM;
	}
	public void setMbrMiddileNM(String mbrMiddileNM) {
		this.mbrMiddileNM = mbrMiddileNM;
	}
	public String getMbrDOB() {
		return mbrDOB;
	}
	public void setMbrDOB(String mbrDOB) {
		this.mbrDOB = mbrDOB;
	}
	public String getMbrResidencyStrAddrNM() {
		return mbrResidencyStrAddrNM;
	}
	public void setMbrResidencyStrAddrNM(String mbrResidencyStrAddrNM) {
		this.mbrResidencyStrAddrNM = mbrResidencyStrAddrNM;
	}
	public String getMbrResidencyStrAddr2NM() {
		return mbrResidencyStrAddr2NM;
	}
	public void setMbrResidencyStrAddr2NM(String mbrResidencyStrAddr2NM) {
		this.mbrResidencyStrAddr2NM = mbrResidencyStrAddr2NM;
	}
	public String getMbrResidencyCityNM() {
		return mbrResidencyCityNM;
	}
	public void setMbrResidencyCityNM(String mbrResidencyCityNM) {
		this.mbrResidencyCityNM = mbrResidencyCityNM;
	}
	public String getMbrResidencyStNM() {
		return mbrResidencyStNM;
	}
	public void setMbrResidencyStNM(String mbrResidencyStNM) {
		this.mbrResidencyStNM = mbrResidencyStNM;
	}
	public String getMbrResidencyZipCD() {
		return mbrResidencyZipCD;
	}
	public void setMbrResidencyZipCD(String mbrResidencyZipCD) {
		this.mbrResidencyZipCD = mbrResidencyZipCD;
	}
	public String getMbrContactNBR() {
		return mbrContactNBR;
	}
	public void setMbrContactNBR(String mbrContactNBR) {
		this.mbrContactNBR = mbrContactNBR;
	}
	public String getNbrOfInsuranceSegments() {
		return nbrOfInsuranceSegments;
	}
	public void setNbrOfInsuranceSegments(String nbrOfInsuranceSegments) {
		this.nbrOfInsuranceSegments = nbrOfInsuranceSegments;
	}
	public String getBeneficiaryPhoneNBR() {
		return beneficiaryPhoneNBR;
	}
	public void setBeneficiaryPhoneNBR(String beneficiaryPhoneNBR) {
		this.beneficiaryPhoneNBR = beneficiaryPhoneNBR;
	}
	public String getPendingOHC() {
		return pendingOHC;
	}
	public void setPendingOHC(String pendingOHC) {
		this.pendingOHC = pendingOHC;
	}
	public String getSegId() {
		return segId;
	}
	public void setSegId(String segId) {
		this.segId = segId;
	}
	public String getSegCarrierCode() {
		return segCarrierCode;
	}
	public void setSegCarrierCode(String segCarrierCode) {
		this.segCarrierCode = segCarrierCode;
	}
	public String getSegPolicyNumber() {
		return segPolicyNumber;
	}
	public void setSegPolicyNumber(String segPolicyNumber) {
		this.segPolicyNumber = segPolicyNumber;
	}
	public String getSegSegmentType() {
		return segSegmentType;
	}
	public void setSegSegmentType(String segSegmentType) {
		this.segSegmentType = segSegmentType;
	}
	public String getSegScopeOfCoverage() {
		return segScopeOfCoverage;
	}
	public void setSegScopeOfCoverage(String segScopeOfCoverage) {
		this.segScopeOfCoverage = segScopeOfCoverage;
	}
	public String getSegPolicyStartDate() {
		return segPolicyStartDate;
	}
	public void setSegPolicyStartDate(String segPolicyStartDate) {
		this.segPolicyStartDate = segPolicyStartDate;
	}
	public String getSegPolicyStopDate() {
		return segPolicyStopDate;
	}
	public void setSegPolicyStopDate(String segPolicyStopDate) {
		this.segPolicyStopDate = segPolicyStopDate;
	}
	public String getSegLastChangeDate() {
		return segLastChangeDate;
	}
	public void setSegLastChangeDate(String segLastChangeDate) {
		this.segLastChangeDate = segLastChangeDate;
	}
	public String getSegTransactionType() {
		return segTransactionType;
	}
	public void setSegTransactionType(String segTransactionType) {
		this.segTransactionType = segTransactionType;
	}
	public String getSegAbsentParentInsuranceFlag() {
		return segAbsentParentInsuranceFlag;
	}
	public void setSegAbsentParentInsuranceFlag(String segAbsentParentInsuranceFlag) {
		this.segAbsentParentInsuranceFlag = segAbsentParentInsuranceFlag;
	}
	public String getSegInsuranceStatusCode() {
		return segInsuranceStatusCode;
	}
	public void setSegInsuranceStatusCode(String segInsuranceStatusCode) {
		this.segInsuranceStatusCode = segInsuranceStatusCode;
	}
	public String getSegRelationShipToPolicyHolder() {
		return segRelationShipToPolicyHolder;
	}
	public void setSegRelationShipToPolicyHolder(String segRelationShipToPolicyHolder) {
		this.segRelationShipToPolicyHolder = segRelationShipToPolicyHolder;
	}
	public String getSegDependentCoverageAvilable() {
		return segDependentCoverageAvilable;
	}
	public void setSegDependentCoverageAvilable(String segDependentCoverageAvilable) {
		this.segDependentCoverageAvilable = segDependentCoverageAvilable;
	}
	public String getSegIEXSourceOfCoverage() {
		return segIEXSourceOfCoverage;
	}
	public void setSegIEXSourceOfCoverage(String segIEXSourceOfCoverage) {
		this.segIEXSourceOfCoverage = segIEXSourceOfCoverage;
	}
	public String getSegTerminationReason() {
		return segTerminationReason;
	}
	public void setSegTerminationReason(String segTerminationReason) {
		this.segTerminationReason = segTerminationReason;
	}
	public String getSegPolicyHolderSSN() {
		return segPolicyHolderSSN;
	}
	public void setSegPolicyHolderSSN(String segPolicyHolderSSN) {
		this.segPolicyHolderSSN = segPolicyHolderSSN;
	}
	public String getSegPolicyHolderLastNM() {
		return segPolicyHolderLastNM;
	}
	public void setSegPolicyHolderLastNM(String segPolicyHolderLastNM) {
		this.segPolicyHolderLastNM = segPolicyHolderLastNM;
	}
	public String getSegPolicyHolderFirstNM() {
		return segPolicyHolderFirstNM;
	}
	public void setSegPolicyHolderFirstNM(String segPolicyHolderFirstNM) {
		this.segPolicyHolderFirstNM = segPolicyHolderFirstNM;
	}
	public String getSegPolicyHolderMiddleInit() {
		return segPolicyHolderMiddleInit;
	}
	public void setSegPolicyHolderMiddleInit(String segPolicyHolderMiddleInit) {
		this.segPolicyHolderMiddleInit = segPolicyHolderMiddleInit;
	}
	public String getSegPolicyHolderAddrLine1() {
		return segPolicyHolderAddrLine1;
	}
	public void setSegPolicyHolderAddrLine1(String segPolicyHolderAddrLine1) {
		this.segPolicyHolderAddrLine1 = segPolicyHolderAddrLine1;
	}
	public String getSegPolicyHolderAddrLine2() {
		return segPolicyHolderAddrLine2;
	}
	public void setSegPolicyHolderAddrLine2(String segPolicyHolderAddrLine2) {
		this.segPolicyHolderAddrLine2 = segPolicyHolderAddrLine2;
	}
	public String getSegPolicyHolderAddrCityState() {
		return segPolicyHolderAddrCityState;
	}
	public void setSegPolicyHolderAddrCityState(String segPolicyHolderAddrCityState) {
		this.segPolicyHolderAddrCityState = segPolicyHolderAddrCityState;
	}
	public String getSegPolicyHolderZipCD() {
		return segPolicyHolderZipCD;
	}
	public void setSegPolicyHolderZipCD(String segPolicyHolderZipCD) {
		this.segPolicyHolderZipCD = segPolicyHolderZipCD;
	}
	public String getSegPolicyHolderZip4() {
		return segPolicyHolderZip4;
	}
	public void setSegPolicyHolderZip4(String segPolicyHolderZip4) {
		this.segPolicyHolderZip4 = segPolicyHolderZip4;
	}
	public String getSegPolicyHolderPhoneNBR() {
		return segPolicyHolderPhoneNBR;
	}
	public void setSegPolicyHolderPhoneNBR(String segPolicyHolderPhoneNBR) {
		this.segPolicyHolderPhoneNBR = segPolicyHolderPhoneNBR;
	}
	public String getSegGrpEmployerNM() {
		return segGrpEmployerNM;
	}
	public void setSegGrpEmployerNM(String segGrpEmployerNM) {
		this.segGrpEmployerNM = segGrpEmployerNM;
	}
	public String getSegGrpEmployerNBR() {
		return segGrpEmployerNBR;
	}
	public void setSegGrpEmployerNBR(String segGrpEmployerNBR) {
		this.segGrpEmployerNBR = segGrpEmployerNBR;
	}
	public String getSegGrpEmployerAddrLine1() {
		return segGrpEmployerAddrLine1;
	}
	public void setSegGrpEmployerAddrLine1(String segGrpEmployerAddrLine1) {
		this.segGrpEmployerAddrLine1 = segGrpEmployerAddrLine1;
	}
	public String getSegGrpEmployerAddrLine2() {
		return segGrpEmployerAddrLine2;
	}
	public void setSegGrpEmployerAddrLine2(String segGrpEmployerAddrLine2) {
		this.segGrpEmployerAddrLine2 = segGrpEmployerAddrLine2;
	}
	public String getSegGrpEmployerCityState() {
		return segGrpEmployerCityState;
	}
	public void setSegGrpEmployerCityState(String segGrpEmployerCityState) {
		this.segGrpEmployerCityState = segGrpEmployerCityState;
	}
	public String getSegGrpEmployerZipCode() {
		return segGrpEmployerZipCode;
	}
	public void setSegGrpEmployerZipCode(String segGrpEmployerZipCode) {
		this.segGrpEmployerZipCode = segGrpEmployerZipCode;
	}
	public String getSegGrpEmployerZip4() {
		return segGrpEmployerZip4;
	}
	public void setSegGrpEmployerZip4(String segGrpEmployerZip4) {
		this.segGrpEmployerZip4 = segGrpEmployerZip4;
	}
	public String getSegGrpEmployerPhoneNumber() {
		return segGrpEmployerPhoneNumber;
	}
	public void setSegGrpEmployerPhoneNumber(String segGrpEmployerPhoneNumber) {
		this.segGrpEmployerPhoneNumber = segGrpEmployerPhoneNumber;
	}
	public String getSegPlanId() {
		return segPlanId;
	}
	public void setSegPlanId(String segPlanId) {
		this.segPlanId = segPlanId;
	}
	public String getHomeInstance() {
		return homeInstance;
	}
	public void setHomeInstance(String homeInstance) {
		this.homeInstance = homeInstance;
	}
	public String getRegionCode() {
		return regionCode;
	}
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	public String getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}
	public Timestamp getInsertTimestamp() {
		return insertTimestamp;
	}
	public void setInsertTimestamp(Timestamp insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}
	public String getInsertUser() {
		return insertUser;
	}
	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}
	public Timestamp getUpdateTimeStamp() {
		return updateTimeStamp;
	}
	public void setUpdateTimeStamp(Timestamp updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getInsertProcess() {
		return insertProcess;
	}
	public void setInsertProcess(String insertProcess) {
		this.insertProcess = insertProcess;
	}
	public Long getInsertProcessId() {
		return insertProcessId;
	}
	public void setInsertProcessId(Long insertProcessId) {
		this.insertProcessId = insertProcessId;
	}
	public String getUpdateProcess() {
		return updateProcess;
	}
	public void setUpdateProcess(String updateProcess) {
		this.updateProcess = updateProcess;
	}
	public Long getUpdateProcessId() {
		return updateProcessId;
	}
	public void setUpdateProcessId(Long updateProcessId) {
		this.updateProcessId = updateProcessId;
	}

	@Override
	public String toString() {
		return "PPCLTransformedOHCRecDTO [transformedOHCRecId=" + transformedOHCRecId + ", transformedOHCFileId="
				+ transformedOHCFileId + ", rcvdOhcBeninfoId=" + rcvdOhcBeninfoId + ", mbrMRN=" + mbrMRN
				+ ", ohcIndicatorCode=" + ohcIndicatorCode + ", mbrSSN=" + mbrSSN + ", mbrMedicaidId=" + mbrMedicaidId
				+ ", mbrRGN=" + mbrRGN + ", mbrPlanNM=" + mbrPlanNM + ", mbrGroupNumber=" + mbrGroupNumber + ", mbrMBI="
				+ mbrMBI + ", mbrFirstNM=" + mbrFirstNM + ", mbrLastNM=" + mbrLastNM + ", mbrMiddileNM=" + mbrMiddileNM
				+ ", mbrDOB=" + mbrDOB + ", mbrResidencyStrAddrNM=" + mbrResidencyStrAddrNM
				+ ", mbrResidencyStrAddr2NM=" + mbrResidencyStrAddr2NM + ", mbrResidencyCityNM=" + mbrResidencyCityNM
				+ ", mbrResidencyStNM=" + mbrResidencyStNM + ", mbrResidencyZipCD=" + mbrResidencyZipCD
				+ ", mbrContactNBR=" + mbrContactNBR + ", nbrOfInsuranceSegments=" + nbrOfInsuranceSegments
				+ ", beneficiaryPhoneNBR=" + beneficiaryPhoneNBR + ", pendingOHC=" + pendingOHC + ", segId=" + segId
				+ ", segCarrierCode=" + segCarrierCode + ", segPolicyNumber=" + segPolicyNumber + ", segSegmentType="
				+ segSegmentType + ", segScopeOfCoverage=" + segScopeOfCoverage + ", segPolicyStartDate="
				+ segPolicyStartDate + ", segPolicyStopDate=" + segPolicyStopDate + ", segLastChangeDate="
				+ segLastChangeDate + ", segTransactionType=" + segTransactionType + ", segAbsentParentInsuranceFlag="
				+ segAbsentParentInsuranceFlag + ", segInsuranceStatusCode=" + segInsuranceStatusCode
				+ ", segRelationShipToPolicyHolder=" + segRelationShipToPolicyHolder + ", segDependentCoverageAvilable="
				+ segDependentCoverageAvilable + ", segIEXSourceOfCoverage=" + segIEXSourceOfCoverage
				+ ", segTerminationReason=" + segTerminationReason + ", segPolicyHolderSSN=" + segPolicyHolderSSN
				+ ", segPolicyHolderLastNM=" + segPolicyHolderLastNM + ", segPolicyHolderFirstNM="
				+ segPolicyHolderFirstNM + ", segPolicyHolderMiddleInit=" + segPolicyHolderMiddleInit
				+ ", segPolicyHolderAddrLine1=" + segPolicyHolderAddrLine1 + ", segPolicyHolderAddrLine2="
				+ segPolicyHolderAddrLine2 + ", segPolicyHolderAddrCityState=" + segPolicyHolderAddrCityState
				+ ", segPolicyHolderZipCD=" + segPolicyHolderZipCD + ", segPolicyHolderZip4=" + segPolicyHolderZip4
				+ ", segPolicyHolderPhoneNBR=" + segPolicyHolderPhoneNBR + ", segGrpEmployerNM=" + segGrpEmployerNM
				+ ", segGrpEmployerNBR=" + segGrpEmployerNBR + ", segGrpEmployerAddrLine1=" + segGrpEmployerAddrLine1
				+ ", segGrpEmployerAddrLine2=" + segGrpEmployerAddrLine2 + ", segGrpEmployerCityState="
				+ segGrpEmployerCityState + ", segGrpEmployerZipCode=" + segGrpEmployerZipCode + ", segGrpEmployerZip4="
				+ segGrpEmployerZip4 + ", segGrpEmployerPhoneNumber=" + segGrpEmployerPhoneNumber + ", segPlanId="
				+ segPlanId + ", homeInstance=" + homeInstance + ", regionCode=" + regionCode + ", recordStatus="
				+ recordStatus + ", insertTimestamp=" + insertTimestamp + ", insertUser=" + insertUser
				+ ", updateTimeStamp=" + updateTimeStamp + ", updateUser=" + updateUser + ", insertProcess="
				+ insertProcess + ", insertProcessId=" + insertProcessId + ", updateProcess=" + updateProcess
				+ ", updateProcessId=" + updateProcessId + "]";
	}
	
}