package org.kpcc.ws.ppcl.properties;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentStringPBEConfig;
import org.kpcc.ws.ppcl.constants.PPCLConstant;
import org.kpcc.ws.ppcl.dto.PPCLErrorConfig;
import org.kpcc.ws.ppcl.dto.KpccConfig;
import org.springframework.util.StringUtils;

public class ApplicationProperties extends Properties {

	private static final Object mutex = new Object();
	public static final String TASK_NAME = "TASK_NAME";
	public static final String TASK_NAME_DEFAULT = "UNKNOWN";
	public static final String CLUSTER_SERVER = "CLUSTER_SERVER";
	public static final String APP_ID = "APP_ID";
	public static final String RESET_SERVER_ID = "RESET_SERVER_ID";
	public static final String MRN_VALIDATOR = "MRN_VALIDATOR";
	private static final String CVG_WS_ENDPOINT_URL = "CVG_WS_ENDPOINT_URL";
	private static final String MBI_WS_ENDPOINT_URL = "MBI_WS_ENDPOINT_URL";
	private static final String CVG_WS_USERNAME = "CVG_WS_USERNAME";
	private static final String CVG_WS_PASSWORD = "CVG_WS_PASSWORD";
	private static final String CVG_DEPLOYMENT_ID = "CVG_DEPLOYMENT_ID";
	private static final String CVG_MRN_TYPE = "CVG_MRN_TYPE";
	private static final String CVG_MARSHALL_CLASS = "CVG_MARSHALL_CLASS";
	private static final String CVG_WS_HTTP_CONNECTION_TIME_OUT_IN_MS = "CVG_WS_HTTP_CONNECTION_TIME_OUT_IN_MS";
	private static final String CVG_WS_HTTP_READ_TIME_OUT_IN_MS = "CVG_WS_HTTP_READ_TIME_OUT_IN_MS";
	private static final String MBI_WS_HTTP_CONNECTION_TIME_OUT_IN_MS = "MBI_WS_HTTP_CONNECTION_TIME_OUT_IN_MS";
	private static final String MBI_WS_HTTP_READ_TIME_OUT_IN_MS = "MBI_WS_HTTP_READ_TIME_OUT_IN_MS";
	private static final String MBI_WS_HTTP_REQUEST_TIME_OUT_IN_MS = "MBI_WS_HTTP_REQUEST_TIME_OUT_IN_MS";
	private static final String HTTP_CONNECTION_TIME_OUT = "HTTP_CONNECTION_TIME_OUT";
	private static final String HTTP_READ_TIME_OUT = "HTTP_READ_TIME_OUT";
	private static final String DATAPOWER_USERNAME = "DATAPOWER_USERNAME";
	private static final String DATAPOWER_PASSWORD = "DATAPOWER_PASSWORD";
	private static final String MBI_WS_COREPOOL_SIZE = "MBI_WS_COREPOOL_SIZE";
	private static final String MBI_WS_MAXPOOL_SIZE = "MBI_WS_MAXPOOL_SIZE";
	private static final String CVG_WS_COREPOOL_SIZE = "CVG_WS_COREPOOL_SIZE";
	private static final String CVG_WS_MAXPOOL_SIZE = "CVG_WS_MAXPOOL_SIZE";
	private static final String NO_COVERAGE_ID_TYPE = "NO-COVERAGE-ID-TYPE";
	private static final String NO_COVERAGE_FOUND = "NO-COVERAGE-FOUND";
	private static final String INVALID_COVERAGE_ID_TYPE = "INVALID-COVERAGE-ID-TYPE";
	private static final String INVALID_DATE = "INVALID-DATE";
	private static final String NO_PATIENT_FOUND = "NO-PATIENT-FOUND";
	private static final String NO_PATIENT_ID = "NO-PATIENT-ID";
	private static final String NO_PATIENT_ID_TYPE = "NO-PATIENT-ID-TYPE";
	private static final String NO_USER_FOUND = "NO-USER-FOUND";
	private static final String NO_USER_ID = "NO-USER-ID";
	private static final String NO_USER_ID_TYPE = "NO-USER-ID-TYPE";
	private static final String INVALID_PATIENT_ID_TYPE = "INVALID-PATIENT-ID-TYPE";
	private static final String INVALID_USER_ID_TYPE = "INVALID-USER-ID-TYPE";
	private static final String REGION_MRN_FORMAT = "REGION_MRN_FORMAT";
	private static final String PERF_LOG = "PERF_LOG";

	private static final String MRN_FORMAT_LENGTH = "MRN_FORMAT_LENGTH";
	private static final String MRN_PREPEND_VALUE = "MRN_PREPEND_VALUE";

	private static final String SUBGROUP_FORMAT_LENGTH = "SUBGROUP_FORMAT_LENGTH";
	private static final String SUBGROUP_TRIM_VALUE = "SUBGROUP_TRIM_VALUE";

	private static final String SUBGROUP_TRIM_FLAG = "SUBGROUP_TRIM_FLAG";

	public static Map<String, String> XWALK_DATA = null;

	private static ApplicationProperties instance;

	private static long WAIT_TIME_IN_SECS_TO_ACCEPT_FILE = 0;
	private static int PRODUCER_FETCH_SIZE = Integer.MAX_VALUE;
	private static int PRODUCER_BATCH_SIZE = 5000;
	private static final StandardPBEStringEncryptor configurationEncryptor;

	static {
		configurationEncryptor = new StandardPBEStringEncryptor();
		EnvironmentStringPBEConfig environmentVariablesConfiguration = new EnvironmentStringPBEConfig();
		environmentVariablesConfiguration.setAlgorithm("PBEWithMD5AndDES");
		environmentVariablesConfiguration.setPassword("SHARED_KEY_2kAYUhcAmayjkJy8Sy+WpgrXyJeus334");
		configurationEncryptor.setConfig(environmentVariablesConfiguration);
	}

	private ApplicationProperties() { }

	public static ApplicationProperties getInstance() {
		synchronized (mutex) {
			if (instance == null) {
				instance = new ApplicationProperties();
			}
		}
		return instance;
	}

	public static String getTaskName() {
		if (getInstance().getProperty(TASK_NAME) == null) {
			return TASK_NAME_DEFAULT;
		}
		return getInstance().get(TASK_NAME).toString();
	}

	public static void loadXwalkdataMapProperties(Map<String, String> xwalkDataMap) {

		ApplicationProperties.XWALK_DATA = xwalkDataMap;

	}

	public static StandardPBEStringEncryptor getEncryptor() {
		return configurationEncryptor;
	}

	public static String getRegion() {
		return (String) getInstance().get(PPCLConstant.REGION);
	}

	public static String getEnv() {
		return (String) getInstance().get(PPCLConstant.ENV);
	}

	public static void loadConfigProperties(List<KpccConfig> listConfig) {

		for (KpccConfig config : listConfig) {
			if (null != config.getParameterValue()) {
				getInstance().put(config.getParameterName(), config.getParameterValue());
			}
		}
	}

	public static void loadErrorConfigProperties(List<PPCLErrorConfig> listErrorConfig) {

		for (PPCLErrorConfig errorConfig : listErrorConfig) {
			if (null != errorConfig.getCode() && null != errorConfig.getMessage()) {
				getInstance().put(errorConfig.getCode(), errorConfig.getMessage());
			}
		}
	}

	public static String getLogFilename() {
		if (ApplicationProperties.getInstance().get(PPCLConstant.LOG_FILE_NAME) != null) {
			return ApplicationProperties.getInstance().get(PPCLConstant.LOG_FILE_NAME).toString();
		}
		return PPCLConstant.FILE_LOG_DEFAULT;
	}

	public static String getFileLogLevel() {
		if (ApplicationProperties.getInstance().get(PPCLConstant.APP_LOG_LEVEL) != null
				&& StringUtils.hasText(ApplicationProperties.getInstance().get(PPCLConstant.APP_LOG_LEVEL).toString())) {
			return ApplicationProperties.getInstance().get(PPCLConstant.APP_LOG_LEVEL).toString();
		}
		return PPCLConstant.FILE_LOG_LEVEL_DEFAULT;
	}

	public static String getConsoleLogLevel() {
		if (ApplicationProperties.getInstance().get(PPCLConstant.CONSOLE_LOG) != null
				&& StringUtils.hasText(ApplicationProperties.getInstance().get(PPCLConstant.CONSOLE_LOG).toString())) {
			return ApplicationProperties.getInstance().get(PPCLConstant.CONSOLE_LOG).toString();
		}
		return PPCLConstant.CONSOLE_LEVEL_DEFAULT;
	}

	public static String getLogPath() {
		if (ApplicationProperties.getInstance().get(PPCLConstant.APP_LOG_PATH) == null) {
			return System.getProperty(PPCLConstant.TEMP_DIR);
		}
		return ApplicationProperties.getInstance().get(PPCLConstant.APP_LOG_PATH).toString() + "/"
				+ ApplicationProperties.getRegion().toLowerCase() + "/"
				+ ApplicationProperties.getInstance().get(PPCLConstant.ENV).toString().toLowerCase();
	}

	public static long getWaitTimeInSecsToAcceptFile() {

		return WAIT_TIME_IN_SECS_TO_ACCEPT_FILE;
	}

	public static int getProducerFetchSize() {
		return PRODUCER_FETCH_SIZE;
	}

	public static int getProducerBatchSize() {
		return PRODUCER_BATCH_SIZE;
	}

	public static Long getApplicationId() {
		return (Long) instance.get(ApplicationProperties.APP_ID);
	}

	public static String getLogArchiveDays() {
		if (ApplicationProperties.getInstance().get(PPCLConstant.LOG_ARCHIVE_DAYS) == null) {
			return PPCLConstant.LOG_ARCHIVE_DAYS_DEFAULT;
		} else {
			return ApplicationProperties.getInstance().get(PPCLConstant.LOG_ARCHIVE_DAYS).toString();
		}
	}

	public static Long getResetConnectionId() {
		return (Long) instance.get(ApplicationProperties.RESET_SERVER_ID);
	}

	public static String getCoverageEndpointUrl() {
		return (String) getInstance().get(CVG_WS_ENDPOINT_URL);
	}

	public static String getCoverageUsername() {
		return (String) getInstance().get(CVG_WS_USERNAME);
	}

	public static String getCoveragePassword() {
		return (String) getInstance().get(CVG_WS_PASSWORD);
	}

	public static String getCoverageDeploymentId() {
		return (String) getInstance().get(CVG_DEPLOYMENT_ID);
	}

	public static String getConnectionTimeout() {
		return (String) getInstance().get(HTTP_CONNECTION_TIME_OUT);
	}

	public static String getConnectionReadTimeout() {
		return (String) getInstance().get(HTTP_READ_TIME_OUT);
	}

	public static String getCoverageMarshallClass() {
		return (String) getInstance().get(CVG_MARSHALL_CLASS);
	}

	public static String getCVGConnectionTimeout() {
		return (String) getInstance().get(CVG_WS_HTTP_CONNECTION_TIME_OUT_IN_MS);
	}

	public static String getCVGConnectionReadTimeout() {
		return (String) getInstance().get(CVG_WS_HTTP_READ_TIME_OUT_IN_MS);
	}

	public static String getMBIConnectionTimeout() {
		return (String) getInstance().get(MBI_WS_HTTP_CONNECTION_TIME_OUT_IN_MS);
	}

	public static String getMBIConnectionReadTimeout() {
		return (String) getInstance().get(MBI_WS_HTTP_READ_TIME_OUT_IN_MS);
	}

	public static String getMBIConnectionRequestTimeout() {
		return (String) getInstance().get(MBI_WS_HTTP_REQUEST_TIME_OUT_IN_MS);
	}

	public static String getMBIEndpointUrl() {
		return (String) getInstance().get(MBI_WS_ENDPOINT_URL);
	}

	public static String getDataPowerUserName() {
		return (String) getInstance().get(DATAPOWER_USERNAME);
	}

	public static String getDataPowerPassword() {
		return (String) getInstance().get(DATAPOWER_PASSWORD);
	}

	public static String getCoverageMRNType() {
		return (String) getInstance().get(CVG_MRN_TYPE);
	}

	public static String getMRNValidator() {
		return (String) getInstance().get(MRN_VALIDATOR);
	}

	public static String getMbiWsCorePooSize() {
		return (String) getInstance().get(MBI_WS_COREPOOL_SIZE);
	}

	public static String getMbiWsMaxPooSize() {
		return (String) getInstance().get(MBI_WS_MAXPOOL_SIZE);
	}

	public static String getCvgWsCorePooSize() {
		return (String) getInstance().get(CVG_WS_COREPOOL_SIZE);
	}

	public static String getCvgWsMaxPooSize() {
		return (String) getInstance().get(CVG_WS_MAXPOOL_SIZE);
	}

	public static String getNoCoverageIdType() {
		return (String) getInstance().get(NO_COVERAGE_ID_TYPE);
	}

	public static String getNoCoverageFound() {
		return (String) getInstance().get(NO_COVERAGE_FOUND);
	}

	public static String getInvalidCoverageIdType() {
		return (String) getInstance().get(INVALID_COVERAGE_ID_TYPE);
	}

	public static String getInvalidDate() {
		return (String) getInstance().get(INVALID_DATE);
	}

	public static String getNoPatientFound() {
		return (String) getInstance().get(NO_PATIENT_FOUND);
	}

	public static String getNoPatientId() {
		return (String) getInstance().get(NO_PATIENT_ID);
	}

	public static String getNoPatientIdType() {
		return (String) getInstance().get(NO_PATIENT_ID_TYPE);
	}

	public static String getNoUserFound() {
		return (String) getInstance().get(NO_USER_FOUND);
	}

	public static String getNoUserId() {
		return (String) getInstance().get(NO_USER_ID);
	}

	public static String getNoUserIdType() {
		return (String) getInstance().get(NO_USER_ID_TYPE);
	}

	public static String getInvalidPatientIdType() {
		return (String) getInstance().get(INVALID_PATIENT_ID_TYPE);
	}

	public static String getInvalidUserIdType() {
		return (String) getInstance().get(INVALID_USER_ID_TYPE);
	}

	public static String getREGION_MRN_FORMAT() {
		return (String) getInstance().get(REGION_MRN_FORMAT);
	}

	public static String getMRN_FORMAT_LENGTH() {
		return (String) getInstance().get(MRN_FORMAT_LENGTH);
	}

	public static String getMRN_PREPEND_VALUE() {
		return (String) getInstance().get(MRN_PREPEND_VALUE);
	}

	public static String getSubgroupTrimValue() {
		return (String) getInstance().get(SUBGROUP_TRIM_VALUE);
	}
	
	public static String getPerfLog() {
		return (String) getInstance().get(PERF_LOG);
	}

}
