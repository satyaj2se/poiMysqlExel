/**
 * 
 */
package org.kpcc.ws.ppcl.repo;


import org.kpcc.ws.ppcl.dto.PPCLPipeStageDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author S492749
 *
 */
@Component
@Transactional
public interface PPCLPipeDelimterRepo extends JpaRepository<PPCLPipeStageDTO,Long>{

}
