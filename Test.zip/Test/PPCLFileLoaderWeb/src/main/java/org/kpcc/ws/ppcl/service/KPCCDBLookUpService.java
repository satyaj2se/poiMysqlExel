/**
 * 
 */
package org.kpcc.ws.ppcl.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.kpcc.ws.ppcl.constants.PPCLConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * @author S492749
 *
 */
@Component
public class KPCCDBLookUpService {
	private static Logger logger = LogManager.getLogger(KPCCDBLookUpService.class);
	
	@Autowired
	@Qualifier("ppclDataSource")
	DataSource dataSource;
	/**
	 * This method will fetch the Member details from MEPDR, 
	 * @param ssn
	 * @return
	 * @throws SQLException
	 */
	public Map<String, String> getMemberDetails(String mrn) throws SQLException {
		Map<String, String> kpccDetails = new HashMap<>();
		try (Connection connection = dataSource.getConnection()) {

			String INITIAL_CONFIG_QUERY = PPCLConstant.KPCC_DB_AUGMENT_QUERY;

			logger.info("---KPCC_CLAIMS_PLATFORM_CONFIG_T Querying---" + INITIAL_CONFIG_QUERY);

			try (PreparedStatement psConfig = connection.prepareStatement(INITIAL_CONFIG_QUERY)) {

				psConfig.setString(1, mrn);
				try (ResultSet rsConfig = psConfig.executeQuery()) {
					while (rsConfig.next()) {
						kpccDetails.put("region_code", rsConfig.getString("region_code"));
						kpccDetails.put("employer_group_no", rsConfig.getString("employer_group_no"));
						kpccDetails.put("plan_group_name", rsConfig.getString("plan_group_name"));
					}
				}
			}
		}
		return kpccDetails;
	}

}
