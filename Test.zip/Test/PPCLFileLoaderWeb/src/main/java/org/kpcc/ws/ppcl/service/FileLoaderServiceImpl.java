package org.kpcc.ws.ppcl.service;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.kpcc.ws.ppcl.constants.PPCLConstant;
import org.kpcc.ws.ppcl.exception.BusinessExceptionMessage;
import org.kpcc.ws.ppcl.file.process.ProcessHISDBCalOptimaFile;
import org.kpcc.ws.ppcl.file.process.ProcessHISDBFile;
import org.kpcc.ws.ppcl.file.process.ProcessHISDBLikeFile;
import org.kpcc.ws.ppcl.file.process.ProcessExcelFile;
import org.kpcc.ws.ppcl.file.process.ProcessPipeDelimiterFile;
import org.kpcc.ws.ppcl.file.process.TransformHISDBToOHC;
import org.kpcc.ws.ppcl.properties.ApplicationProperties;
import org.kpcc.ws.ppcl.utils.DatabaseUtils;
import org.kpcc.ws.ppcl.vo.PPCLResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class FileLoaderServiceImpl implements FileLoaderService {

	private static Logger logger = LogManager.getLogger(FileLoaderServiceImpl.class);

	@Autowired
	@Qualifier("ppclDataSource")
	DataSource ppclDataSource;

	@Autowired
	private ProcessHISDBFile processHISDBFile;

	@Autowired
	private ProcessHISDBLikeFile processHISDBLikeFile;

	@Autowired
	private ProcessHISDBCalOptimaFile processHISDBCalOptima;
	
	@Autowired
	private TransformHISDBToOHC transformHISDBToOHC;
	
	@Autowired
	private ProcessPipeDelimiterFile processPipeDelimiterFile;
	
	@Autowired
	private ProcessExcelFile processIEHPXLSFile;

	private static final String[] KEYS = { PPCLConstant.LOADER_INBOUND_PATH, PPCLConstant.LOADER_OUTBOUND_PATH,
			PPCLConstant.LOADER_WORKING_PATH, PPCLConstant.LOADER_ARCHIVE_PATH, PPCLConstant.LOADER_ERROR_PATH };

	@Override
	public Map<String, String> getLZFromConfig() {
		Map<String, String> lzMap = new HashMap<>();
		String value = "";
		for (String key : KEYS) {
			if (!ApplicationProperties.getInstance().containsKey(key)) {
				try {
					DatabaseUtils.getPropFromConfigByApp(ppclDataSource);
				} catch (Exception e) {
					logger.error("Couldn't load landing zones: " + e.getMessage());
				}
			}
			value = ApplicationProperties.getInstance().getProperty(key);
			lzMap.put(key, value);
		}
		return lzMap;
	}

	@Override
	public String getFileType(String name) {
		String value = "";
		if(StringUtils.isNotBlank(name) && name.split("_").length > 0) {
			String ppName = name.split("_")[1];
			if (!ApplicationProperties.getInstance().containsKey(ppName)) {
				try {
					DatabaseUtils.getPropFromConfigByApp(ppclDataSource);
				} catch (Exception e) {
					logger.error("Couldn't load file type for given plan partner: " + name + " , due to " +e.getMessage());
				}
			}
			value = ApplicationProperties.getInstance().getProperty(ppName);
		}
		return value;
	}

	@Override
	public String processPPFileFromLZ() {
		String status = "";
		PPCLResponse res = new PPCLResponse();
		Map<String, String> lzMap = getLZFromConfig();

		try {
			File directoryPath = new File(lzMap.get(PPCLConstant.LOADER_INBOUND_PATH));
			String contents[] = directoryPath.list();
			String fileType = "";

			if (contents != null && contents.length > 0) {
				for (String fileName : contents) {
					fileType = getFileType(fileName);
					File ppFile = null;
					//TODO the file type for few regions are yet to finalize, Once fixed this if loop can be removed.
				  if(fileName.contains("CalOptima")){
						fileType = PPCLConstant.FILE_TYPE_HISDB_LIKE_CALOPTIMA;
					} else if(fileName.contains("SCFHP")) {
						fileType = PPCLConstant.FILE_TYPE_HISDB_LIKE_PIPE;
					}
					// remove above if loop once file types are finalized
					switch (fileType) {
					case PPCLConstant.FILE_TYPE_HISDB:
						ppFile = new File(directoryPath.getPath().concat("\\").concat(fileName));
						status = processHISDBFile.processHisDBData(lzMap, ppFile);
						res.setStatus(status);
						break;
					case PPCLConstant.FILE_TYPE_HISDB_LIKE_SM:
						ppFile = new File(directoryPath.getPath().concat("\\").concat(fileName));
						status = processHISDBLikeFile.processHisDBLikeData(lzMap, ppFile);
						res.setStatus(status);
						break;
					case PPCLConstant.FILE_TYPE_HISDB_LIKE_CALOPTIMA:
						ppFile = new File(directoryPath.getPath().concat("\\").concat(fileName));
						status = processHISDBCalOptima.processHisDBLikeCalData(lzMap, ppFile);
						res.setStatus(status);
						break;
					case PPCLConstant.FILE_TYPE_HISDB_LIKE_PIPE:
						ppFile = new File(directoryPath.getPath().concat("\\").concat(fileName));
						status = processPipeDelimiterFile.processPipeDelimiterData(lzMap, ppFile);
						res.setStatus(status);
						break;
					case PPCLConstant.FILE_TYPE_HISDB_XLS:
						ppFile = new File(directoryPath.getPath().concat("\\").concat(fileName));
						status = processIEHPXLSFile.processExcelData(lzMap, ppFile);
						res.setStatus(status);
						break;
					default:
						throw new BusinessExceptionMessage("Unsupported file type identified.");
					}
				}
			} else {
				throw new BusinessExceptionMessage("No files found in the directory");
			}
		} catch (BusinessExceptionMessage be) {
			logger.error("Exception while processing : " + be.getMessage());
			res.setStatus("Error");
			res.setCode(be.getErrorCode());
			res.setMessage(be.getMessage());
		} catch (Exception e) {
			logger.error("Exception while processing the request. Please try again.");
			res.setStatus("Error");
			res.setMessage(e.getMessage());
		}
		return res.toString();
	}

	@Override
	public String transformHISDBtoOHC() {
		Map<String, String> fcMap = getFiltersFromConfig();
		String status = transformHISDBToOHC.transFormHHISDBtoOHC(fcMap);
		PPCLResponse res = new PPCLResponse(status, "", "");
		return res.toString();
	}

	@Override
	public Map<String, String> getFiltersFromConfig() {
		Map<String, String> fcMap = new HashMap<>();
		String value = "";
		for (String key : PPCLConstant.FILTER_KEYS) {
			if (!ApplicationProperties.getInstance().containsKey(key)) {
				try {
					DatabaseUtils.getPropFromConfigByApp(ppclDataSource);
				} catch (Exception e) {
					logger.error("Couldn't load landing zones: " + e.getMessage());
				}
			}
			value = ApplicationProperties.getInstance().getProperty(key);
			fcMap.put(key, value);
		}
		return fcMap;
	}
	
	/**
	 * This is a temp method to get local lz for dev testing in local
	 * 
	 * @return
	 */
	private Map<String, String> getTempLZ() {
		Map<String, String> lzMap = new HashMap<>();
		lzMap.put(PPCLConstant.LOADER_INBOUND_PATH, "P:\\apps\\kpcc\\n1\\dit\\ppcl\\inbound");
		lzMap.put(PPCLConstant.LOADER_OUTBOUND_PATH, "P:\\apps\\kpcc\\n1\\dit\\ppcl\\outbound");
		lzMap.put(PPCLConstant.LOADER_WORKING_PATH, "P:\\apps\\kpcc\\n1\\dit\\ppcl\\working");
		lzMap.put(PPCLConstant.LOADER_ERROR_PATH, "P:\\apps\\kpcc\\n1\\dit\\ppcl\\error");
		lzMap.put(PPCLConstant.LOADER_ARCHIVE_PATH, "P:\\apps\\kpcc\\n1\\dit\\ppcl\\archive");

		return lzMap;
	}
}
