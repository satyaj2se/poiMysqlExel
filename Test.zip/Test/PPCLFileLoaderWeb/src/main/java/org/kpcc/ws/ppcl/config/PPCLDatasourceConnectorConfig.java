package org.kpcc.ws.ppcl.config;

import java.util.HashMap;
import java.util.logging.Logger;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * The method to configure entitymanager and transaction manager object to connect to the
 * database with pojo classes and JNDi datasource 
 * @author S492749
 *
 */
@Configuration
@EnableTransactionManagement

@EnableJpaRepositories(entityManagerFactoryRef = "entityManager", transactionManagerRef = "transactionManager", basePackages = {
		"org.kpcc.ws.ppcl.repo" })
public class PPCLDatasourceConnectorConfig {

	private static Logger logger = Logger.getLogger(PPCLDatasourceConnectorConfig.class.getName());

	@Autowired
	@Qualifier("ppclDataSource")
	DataSource ppclDataSource;

	@Bean
	@Primary
	public LocalContainerEntityManagerFactoryBean entityManager() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(ppclDataSource);
		em.setPackagesToScan(new String[] { "org.kpcc.ws.ppcl.dto" });

		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		HashMap<String, Object> properties = new HashMap<>();
		properties.put("hibernate.hbm2ddl.auto", "update");
		properties.put("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
		em.setJpaPropertyMap(properties);

		return em;
	}

	@Primary
	@Bean(name = "transactionManager")
	public PlatformTransactionManager transactionManager(
			@Qualifier("entityManager") EntityManagerFactory entityManager) {
		return new JpaTransactionManager(entityManager);
	}

}
