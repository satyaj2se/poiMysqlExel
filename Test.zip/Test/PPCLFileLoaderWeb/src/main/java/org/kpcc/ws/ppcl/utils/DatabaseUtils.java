package org.kpcc.ws.ppcl.utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.kpcc.ws.ppcl.constants.PPCLConstant;
import org.kpcc.ws.ppcl.dto.KpccConfig;
import org.kpcc.ws.ppcl.dto.PPCLErrorConfig;
import org.kpcc.ws.ppcl.exception.SystemCriticalException;
import org.kpcc.ws.ppcl.properties.ApplicationProperties;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jndi.JndiLocatorDelegate;

public class DatabaseUtils {

    private static final JndiLocatorDelegate jndi = JndiLocatorDelegate.createDefaultResourceRefLocator();
    private static DataSource dataSource = null;
    private static DataSource mepdrDataSource = null;
    private static String username;

    public static String getDatabseUsername() {
        if (username == null) {
            try {
                DataSource dataSource = DatabaseUtils.getDataSource();
                try (Connection con = dataSource.getConnection()) {
                    username = con.getMetaData().getUserName();
                } catch (SQLException e) {
                    username = "PPCLWS";
                }
            } catch (Throwable e) {
                username = "PPCLWS";
            }
        }
        return username;
    }

    /**
     * This method returns the data source object for KPCC DB.
     * @return DataSource
     */
    public static DataSource getDataSource() {
        if (null == dataSource) {
            try {
                dataSource = jndi.lookup(getProperties(PPCLConstant.APPLICATION_PROPERTIES).getProperty(PPCLConstant.CONFIG_JNDI_NAME), DataSource.class);
            } catch (Exception e) {
                throw new RuntimeException("JNDI lookup failed", e);
            }
        }
        return dataSource;
    }

    /**
     * This method returns the data source object for MEPDR DB.
     * @return DataSource
     */
    public static DataSource getMEPDRDataSource() {
        if (null == mepdrDataSource) {
            try {
            	mepdrDataSource = jndi.lookup(getProperties(PPCLConstant.APPLICATION_PROPERTIES).getProperty(PPCLConstant.CONFIG_JNDI_MEPDR_NAME), DataSource.class);
            } catch (Exception e) {
                throw new RuntimeException("JNDI lookup failed", e);
            }
        }
        return mepdrDataSource;
    }

    /**
     * This method can be used to get the property value from the given filename (eg. application.properties)
     * @param filename
     * @return Properties
     */
    public static Properties getProperties(String filename) {
        try (InputStream inputStream = new ClassPathResource(String.format("/%s", filename)).getInputStream()) {
            Properties props = new Properties();
            props.load(inputStream);
            return props;
        } catch (IOException e) {
            throw new SystemCriticalException("No application name/domain name defined in application.properties.");
        }
    }

    /**
     * Load the given properties to the application
     * @param properties
     */
    public static void loadApplicationProperties(Properties properties) {
        for (Map.Entry<Object, Object> ey : properties.entrySet()) {
        	 ApplicationProperties.getInstance().put(ey.getKey().toString(), ey.getValue().toString());
         
        }
    }

    /**
     * Load the config details from the config table  through the datasource provided.
     * @param dataSource
     * @return List<KpccConfig>
     * @throws SQLException
     */
    public static List<KpccConfig> loadConfig(DataSource dataSource) throws SQLException {

        Timestamp current = new Timestamp(System.currentTimeMillis());
        List<KpccConfig> listConfig = new LinkedList<>();
        try (Connection connection = dataSource.getConnection()) {
            if (ApplicationProperties.getEnv() == null) {
                updateEnv(connection);
            }
            if (ApplicationProperties.getRegion() == null) {
                updateRegion(connection);
            }
            String sql = sqlConfig();
            try (PreparedStatement psConfig = connection.prepareStatement(sql)) {
                psConfig.setTimestamp(1, current);
                psConfig.setTimestamp(2, current);
                try (ResultSet rsConfig = psConfig.executeQuery()) {
                    while (rsConfig.next()) {
                        String parameter_value;
                        if ("Y".equalsIgnoreCase(rsConfig.getString(PPCLConstant.ENCRYPTED_FLAG))) {
                            parameter_value = ApplicationProperties.getEncryptor().decrypt(rsConfig.getString(PPCLConstant.PARAMETER_VALUE));
                        } else {
                            parameter_value = rsConfig.getString(PPCLConstant.PARAMETER_VALUE);
                        }

                        KpccConfig config = new KpccConfig();
                        config.setParameterName(rsConfig.getString(PPCLConstant.PARAMETER_NAME));
                        config.setSelector(rsConfig.getString(PPCLConstant.SELECTOR));
                        config.setParameterValue(parameter_value);
                        listConfig.add(config);
                    }
                }
            }
        }
        return listConfig;
    }

    /**
     * Load the error config details from the error config table  through the datasource provided.
     * @param dataSource
     * @return
     * @throws SQLException
     */
    public static List<PPCLErrorConfig> loadErrorConfig(DataSource dataSource) throws SQLException {

        List<PPCLErrorConfig> listErrorConfig = new LinkedList<>();
        try (Connection connection = dataSource.getConnection()) {
            if (ApplicationProperties.getEnv() == null) {
                updateEnv(connection);
            }
            if (ApplicationProperties.getRegion() == null) {
                updateRegion(connection);
            }
            String sql = sqlErrorConfig();
            try (PreparedStatement psConfig = connection.prepareStatement(sql)) {
                try (ResultSet rsConfig = psConfig.executeQuery()) {
                    while (rsConfig.next()) {
                    	PPCLErrorConfig errorConfig = new PPCLErrorConfig();
                        errorConfig.setCode(rsConfig.getString(PPCLConstant.ERROR_CODE));
                        errorConfig.setMessage(rsConfig.getString(PPCLConstant.ERROR_DESCRIPTION));                       
                        listErrorConfig.add(errorConfig);
                    }
                }
            }
        }
        return listErrorConfig;
    }
    
    /**
     * This method can be used to get the details from the config table wrt application
     * @param dataSource
     * @return
     * @throws SQLException
     */
    public static void getPropFromConfigByApp(DataSource dataSource) throws SQLException {

		List<KpccConfig> listConfig = new LinkedList<>();
		try (Connection connection = dataSource.getConnection()) {
			String INITIAL_CONFIG_QUERY = "SELECT REGION_CODE, PARAMETER_NAME, PARAMETER_VALUE FROM KPCCINT.KPCC_CLAIMS_PLATFORM_CONFIG_T Where APPLICATION=?";

			try (PreparedStatement psConfig = connection.prepareStatement(INITIAL_CONFIG_QUERY)) {
				String appName = ApplicationProperties.getInstance().getProperty(PPCLConstant.PPCL_CONFIG_APPLICATION, PPCLConstant.DEFAULT_APP_NAME);
				psConfig.setString(1, appName);
				try (ResultSet rsConfig = psConfig.executeQuery()) {
					KpccConfig config = null;
					while (rsConfig.next()) {
						config = new KpccConfig();
						config.setRegionCode(rsConfig.getString(PPCLConstant.REGION_CODE));
						config.setParameterName(rsConfig.getString(PPCLConstant.PARAMETER_NAME));
						config.setParameterValue(rsConfig.getString(PPCLConstant.PARAMETER_VALUE));
						listConfig.add(config);
					}
				}
			}
			if(!listConfig.isEmpty()) {
				ApplicationProperties.loadConfigProperties(listConfig);
			}
		}
	}
    
    private static void updateRegion(Connection connection) throws SQLException {
        try (PreparedStatement psConfig = connection.prepareStatement("SELECT CMN_UTILITY_PK.CMN_GET_REGION_CODE_SP() REGION FROM DUAL")) {
            try (ResultSet rsConfig = psConfig.executeQuery()) {
                if (rsConfig.next()) {
                    ApplicationProperties.getInstance().setProperty(PPCLConstant.REGION, rsConfig.getString(PPCLConstant.REGION_STRING));
                }
            }
        }
    }

    private static void updateEnv(Connection connection) throws SQLException {
        try (PreparedStatement psConfig = connection.prepareStatement("SELECT CMN_UTILITY_PK.CMN_GET_ENVIRONMENT_CODE_SP() ENV FROM DUAL")) {
            try (ResultSet rsConfig = psConfig.executeQuery()) {
                if (rsConfig.next()) {
                    ApplicationProperties.getInstance().setProperty(PPCLConstant.ENV, rsConfig.getString(PPCLConstant.ENV));
                }
            }
        }
    }

    private static String sqlConfig() {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(PPCLConstant.INITIAL_CONFIG_QUERY);
        sqlBuilder.append(String.format(" AND APPLICATION='%s'", ApplicationProperties.getInstance().get(PPCLConstant.PPCL_CONFIG_APPLICATION).toString().trim()));
        sqlBuilder.append(String.format(" AND DOMAIN_GROUP = '%s'", ApplicationProperties.getInstance().get(PPCLConstant.PPCL_DOMAIN_GROUP).toString().trim()));
        sqlBuilder.append(String.format(" AND REGION_CODE='%s'", ApplicationProperties.getInstance().get(PPCLConstant.REGION).toString().trim()));
        sqlBuilder.append(" AND  SELECTOR IN (");
        sqlBuilder.append(String.format("'%s'",ApplicationProperties.getInstance().get(PPCLConstant.PPCL_CONFIG_SELECTOR).toString().trim().split(",")[0]));
        sqlBuilder.append(" )");
        return sqlBuilder.toString();
    }
    
    private static String sqlErrorConfig() {
    	 StringBuilder sqlBuilder = new StringBuilder();
         sqlBuilder.append(PPCLConstant.ERROR_CONFIG_QUERY);
         sqlBuilder.append(String.format(" WHERE APPLICATION='%s'", ApplicationProperties.getInstance().get(PPCLConstant.PPCL_CONFIG_APPLICATION).toString().trim()));
         sqlBuilder.append(String.format(" AND DOMAIN_GROUP = '%s'", ApplicationProperties.getInstance().get(PPCLConstant.PPCL_DOMAIN_GROUP).toString().trim()));
         sqlBuilder.append(String.format(" AND REGION_CODE='%s'", ApplicationProperties.getInstance().get(PPCLConstant.REGION).toString().trim()));
         return sqlBuilder.toString();
    }
        
}
