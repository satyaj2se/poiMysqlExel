package org.kpcc.ws.ppcl.repo;

import java.util.List;

import org.kpcc.ws.ppcl.dto.PPCLHISDBBenIfoStageDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public interface PPCLHISDBBenInfoStageRepo extends JpaRepository<PPCLHISDBBenIfoStageDTO,Long> {

	@Query(value="SELECT * FROM PPCL_HISDB_BENINFO_STG_T WHERE RECORD_STATUS = ?", nativeQuery = true)
	public List<PPCLHISDBBenIfoStageDTO> findAllBystatus(String status);
}
