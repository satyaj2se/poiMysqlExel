package org.kpcc.ws.ppcl.utils;

import javax.naming.NamingException;

import org.springframework.jndi.JndiLocatorSupport;
import org.springframework.stereotype.Component;

@Component
public class JNDIUtil extends JndiLocatorSupport{
	
	public static JNDIUtil jndiUtil = new JNDIUtil();
	
	private JNDIUtil(){
		setResourceRef(true);
	}
	
	/**
	 * 
	 * @param jndiName
	 * @param encrypted
	 * @return
	 * @throws NamingException 
	 * @throws Exception 
	 */
	public static String getJNDIValue(String jndiName, boolean encrypted) throws NamingException{
		
		if(encrypted){
			String passWord = null;
			passWord =  jndiUtil.lookup(jndiName, String.class);
			return DateUtil.getDecode(passWord);
		}else{
			return jndiUtil.lookup(jndiName, String.class);
		}
		
	}

}
