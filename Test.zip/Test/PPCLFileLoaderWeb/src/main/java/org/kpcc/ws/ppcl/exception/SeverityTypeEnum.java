
package org.kpcc.ws.ppcl.exception;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SeverityTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SeverityTypeEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="CRITICAL"/&gt;
 *     &lt;enumeration value="HIGH"/&gt;
 *     &lt;enumeration value="MEDIUM"/&gt;
 *     &lt;enumeration value="LOW"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "SeverityTypeEnum")
@XmlEnum
public enum SeverityTypeEnum {

    CRITICAL,
    HIGH,
    MEDIUM,
    LOW;

    public String value() {
        return name();
    }

    public static SeverityTypeEnum fromValue(String v) {
        return valueOf(v);
    }

}
