package org.kpcc.ws.ppcl.context;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.kpcc.ws.ppcl.constants.PPCLConstant;
import org.kpcc.ws.ppcl.dto.KpccConfig;
import org.kpcc.ws.ppcl.dto.PPCLErrorConfig;
import org.kpcc.ws.ppcl.properties.ApplicationProperties;
import org.kpcc.ws.ppcl.utils.DatabaseUtils;

public class PPCLContextListner implements ServletContextListener {

	private static Logger logger = LogManager.getLogger(PPCLContextListner.class.getName());
	
	@Override
	public void contextInitialized(ServletContextEvent event) {

		try {
			logger.info(" PPCL contextInitialized..");
			DatabaseUtils.loadApplicationProperties(DatabaseUtils.getProperties("application.properties"));
	        logger.info("Initial context application properties");
	        
	        setUpContext(event);
	        logger.info("Done PPCLContextListner .contextInitialized");
		} catch (Exception e) {
			logger.info("Initial Error {}"+e.getMessage());
		}
	}

	private void setUpContext(ServletContextEvent event) throws SQLException {
		logger.info("Start PPCL Application...");
		
		DataSource kpccDS = DatabaseUtils.getDataSource();
        List<KpccConfig> configList = DatabaseUtils.loadConfig(kpccDS);
        
        if(configList.isEmpty())
        {
        	throw new RuntimeException(
                    "Application config properties not found in DB for region : " + ApplicationProperties.getRegion()
                            + ", domain_group : " + ApplicationProperties.getInstance().get(PPCLConstant.PPCL_DOMAIN_GROUP) + " application : "
                            + ApplicationProperties.getInstance().get(PPCLConstant.PPCL_CONFIG_APPLICATION));
        }
        else 
        {
        	ApplicationProperties.loadConfigProperties(configList);
        	List<PPCLErrorConfig> listErrorConfig = DatabaseUtils.loadErrorConfig(kpccDS);
	        if (listErrorConfig.isEmpty()) {
	            throw new RuntimeException(
	                    "Application error config properties not found in DB for region : " + ApplicationProperties.getRegion()
	                            + ", domain_group : " + ApplicationProperties.getInstance().get(PPCLConstant.PPCL_DOMAIN_GROUP) + " application : "
	                            + ApplicationProperties.getInstance().get(PPCLConstant.PPCL_CONFIG_APPLICATION));
	        }
	        ApplicationProperties.loadErrorConfigProperties(listErrorConfig);
        }
		
	}

	@Override
	public void contextDestroyed(ServletContextEvent event) {

	}
}
