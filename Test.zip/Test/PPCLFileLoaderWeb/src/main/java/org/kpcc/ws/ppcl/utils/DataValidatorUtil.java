package org.kpcc.ws.ppcl.utils;

import org.apache.commons.lang3.StringUtils;
import org.kpcc.ws.ppcl.dto.PPCLHISDBBenIfoStageDTO;
import org.kpcc.ws.ppcl.dto.PPCLHISDBCarrierStageDTO;
import org.kpcc.ws.ppcl.dto.PPCLPipeStageDTO;

/**
 * @author S492749
 *
 */
public class DataValidatorUtil {

	/**
	 * Validates whether the given DTO has all the required fields.
	 * @param pipeDTO
	 * @return
	 */
	public static boolean isPipeDataValid(PPCLPipeStageDTO pipeDTO) {
		//TODO include checks for all the required fields
		boolean isValid = (pipeDTO != null && 
				(
					StringUtils.isNotBlank(pipeDTO.getMedsId()) &&	
					StringUtils.isNotBlank(pipeDTO.getCin()) &&
					StringUtils.isNotBlank(pipeDTO.getBeneficiaryPhoneNbr()) &&
					StringUtils.isNotBlank(pipeDTO.getCarrierName1()) &&
					StringUtils.isNotBlank(pipeDTO.getCarrierStreetAddress1()) &&
					StringUtils.isNotBlank(pipeDTO.getCarrierStreetAddress2()) &&
					StringUtils.isNotBlank(pipeDTO.getCarrierCity()) &&
					StringUtils.isNotBlank(pipeDTO.getCarrierState()) &&
					StringUtils.isNotBlank(pipeDTO.getCarrierZip()) &&
					StringUtils.isNotBlank(pipeDTO.getCarrierZip4()) &&
					StringUtils.isNotBlank(pipeDTO.getCarrierPhone()) &&
					StringUtils.isNotBlank(pipeDTO.getCarrierOHCCode()) &&  
					StringUtils.isNotBlank(pipeDTO.getCarrierCode()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyNumber()) &&
					StringUtils.isNotBlank(pipeDTO.getScopeofCoverage()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyStartDate()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyStopDate()) &&
					StringUtils.isNotBlank(pipeDTO.getLastChangeDate()) &&
					StringUtils.isNotBlank(pipeDTO.getRelationshiptoPolicyHolder()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyHolderLastName()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyHolderFirstName()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyHolderMiddleInitial()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyHolderAddressLine1()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyHolderAddressLine2()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyHolderCityState()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyHolderZipCode()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyHolderPhoneNumber()) &&
					StringUtils.isNotBlank(pipeDTO.getPolicyHolderZip4())));
					
		return isValid;
	}
	
	/**
	 * Validates whether the given DTO has all the required fields.
	 * @param benInfo
	 * @return
	 */
	public static boolean isBenInfoValid(PPCLHISDBBenIfoStageDTO benInfo) {
		// TODO include checks for all the required fields
		boolean isValid = (benInfo != null && (StringUtils.isNotBlank(benInfo.getMedsId())
				&& StringUtils.isNotBlank(benInfo.getRecordStatus())
				&& StringUtils.isNotBlank(benInfo.getRegionCode())
				&& StringUtils.isNotBlank(benInfo.getNbrOfInsuranceSegments())));

		return isValid;
	}
	
	/**
	 * Validates whether the given DTO has all the required fields.
	 * @param carrierStage
	 * @return
	 */
	public static boolean isCarrierStageValid(PPCLHISDBCarrierStageDTO carrierStage) {
		//TODO include checks for all the required fields
		boolean isValid = (carrierStage != null && 
					(
						StringUtils.isNotBlank(carrierStage.getMedsId()) && 
						StringUtils.isNotBlank(carrierStage.getInsuranceStatusCode()) &&
						StringUtils.isNotBlank(carrierStage.getSegmentTyp()) &&
						StringUtils.isNotBlank(carrierStage.getScopOfCoverage()) &&
						StringUtils.isNotBlank(carrierStage.getPolicyStartDate()) &&
						StringUtils.isNotBlank(carrierStage.getPolicyStopDate()) &&
						StringUtils.isNotBlank(carrierStage.getLastChangeDate()) &&
						StringUtils.isNotBlank(carrierStage.getTransactionTyp()) &&
						StringUtils.isNotBlank(carrierStage.getPolicyStartDate()) &&
						StringUtils.isNotBlank(carrierStage.getPolicyHolderSSN()) &&
						StringUtils.isNotBlank(carrierStage.getPolicyHolderLastNM()) &&
						StringUtils.isNotBlank(carrierStage.getPolicyHolderFirstNM()) &&
						StringUtils.isNotBlank(carrierStage.getPolicyHolderMiddleInitial()) &&
						StringUtils.isNotBlank(carrierStage.getPolicyHolderAddrLine1()) &&
						StringUtils.isNotBlank(carrierStage.getPolicyHolderCityState()) &&
						StringUtils.isNotBlank(carrierStage.getGroupEmployerName()) &&
						StringUtils.isNotBlank(carrierStage.getGroupEmployerNumber()) &&
						StringUtils.isNotBlank(carrierStage.getGroupEmployerAddrLine1()) &&
						StringUtils.isNotBlank(carrierStage.getGroupEmployerAddrLine2()) &&
						StringUtils.isNotBlank(carrierStage.getGroupEmployerCityState()) &&
						StringUtils.isNotBlank(carrierStage.getGroupEmployerZipCD()) &&
						StringUtils.isNotBlank(carrierStage.getGroupEmployerZip4()) &&
						StringUtils.isNotBlank(carrierStage.getGroupEmployerPhoneNbr()) &&
						StringUtils.isNotBlank(carrierStage.getPlanId()))
);
		
		return isValid;
	}
}
