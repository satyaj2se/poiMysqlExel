package org.kpcc.ws.ppcl.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.kpcc.ws.ppcl.constants.PPCLConstant;
import org.kpcc.ws.ppcl.exception.SystemCriticalException;
import org.kpcc.ws.ppcl.properties.ApplicationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jndi.JndiLocatorDelegate;

@Configuration
public class PPCLDataSourceConfig {

	private static Logger logger = Logger.getLogger(PPCLDataSourceConfig.class.getName());
	private static final JndiLocatorDelegate jndi = JndiLocatorDelegate.createDefaultResourceRefLocator();
	private static DataSource dataSource = null;
	private static DataSource MEPDRDataSource = null;

	
	@Bean(name = "ppclDataSource")
	public DataSource dataSource() throws NamingException {
		try {
			InitialContext ctx = new InitialContext();
			dataSource = (DataSource) ctx.lookup("jdbc/ppclDatasource");
			logger.info("****PPCL Database JNDI Lookup**" + dataSource);
		} catch (Exception exc) {
			exc.printStackTrace();
		}
		return dataSource;
	}

	

	public static DataSource getDataSource() {
		if (null == dataSource) {
			try {
				dataSource = jndi.lookup(getProperties(PPCLConstant.APPLICATION_PROPERTIES)
						.getProperty(PPCLConstant.CONFIG_JNDI_NAME), DataSource.class);
			} catch (Exception e) {
				throw new RuntimeException("***TODO For Properties File Based **", e);
			}
		}
		return dataSource;
	}

	public static Properties getProperties(String filename) {
		try (InputStream inputStream = new ClassPathResource(String.format("/properties/%s", filename))
				.getInputStream()) {
			Properties props = new Properties();
			props.load(inputStream);
			return props;
		} catch (IOException e) {
			throw new SystemCriticalException("No application name/domain name defined in application.properties.");
		}
	}

	public static void loadApplicationProperties(Properties properties) {
		for (Map.Entry<Object, Object> ey : properties.entrySet()) {
			ApplicationProperties.getInstance().put(ey.getKey().toString(), ey.getValue().toString());

		}

	}
}
