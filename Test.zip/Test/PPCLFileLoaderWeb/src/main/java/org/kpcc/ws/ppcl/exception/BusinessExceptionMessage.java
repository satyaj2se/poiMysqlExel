package org.kpcc.ws.ppcl.exception;

public class BusinessExceptionMessage extends Exception {

	private String errorCode;
	private String errorDesc;
	private BusinessExceptionType businessException;

	public BusinessExceptionMessage(String errorCode, String errorDesc) {
		super(errorCode + ":" + errorDesc);
		this.errorCode = errorCode;
		this.errorDesc = errorDesc;
	}

	public BusinessExceptionMessage(String message, BusinessExceptionType businessException) {
		super(message);
		this.businessException = businessException;
	}

	public BusinessExceptionMessage() {
		super();
	}

	public BusinessExceptionMessage(String message) {
		super(message);
	}

	public BusinessExceptionMessage(String message, Throwable cause) {
		super(message, cause);
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public BusinessExceptionType getBusinessException() {
		return businessException;
	}

	public void setBusinessException(BusinessExceptionType businessException) {
		this.businessException = businessException;
	}

	@Override
	public String toString() {
		return "BusinessExceptionMessage [errorCode=" + errorCode + ", errorDesc=" + errorDesc + "]";
	}	
	

}
