package org.kpcc.ws.ppcl.constants;

public interface PPCLConstant {
	
	String INITIAL_CONFIG_QUERY = String
            .format("%s%s", "SELECT SELECTOR, PARAMETER_NAME, PARAMETER_VALUE, ENCRYPTED_FLAG FROM KPCC_CLAIMS_PLATFORM_CONFIG_T ",
                    "WHERE ACTIVE_FLAG = 'Y' AND ? BETWEEN EFFECTIVE_DATE AND NVL(TERM_DATE, ?) ");
	String ERROR_CONFIG_QUERY = String.format("%s", "SELECT ERROR_CODE, ERROR_DESCRIPTION from KPCC_CLAIMS_PLATFORM_ERROR_T ");
	
	String EPIC_SERVICE_DATE_FORMAT = "MM/dd/yyyy";
    String COMP_DATE_FORMAT = "yyyy-MM-dd";
    String PPCL_DEFAULT_CONFIG = "PPCL_DEFAULT_CONFIG";
    String REGION = "config.region";
    String THREAD_POOL_SIZE = "THREAD_POOL_SIZE";    
    String APP_LOG_PATH = "APP_LOG_PATH";
    String LOG_FILE_NAME = "config.log4j.name";
    String APP_LOG_LEVEL = "APP_LOG_LEVEL";
    String CONSOLE_LOG = "CONSOLE_LOG";
    String TEMP_DIR = "java.io.tmpdir";
    String FILE_LOG_LEVEL_DEFAULT = "INFO";
    String CONSOLE_LEVEL_DEFAULT = "INFO";
    String FILE_LOG_DEFAULT = "PPCL";
    String DEFAULT_APP_NAME = "PPCL_FILE_LOADER";
    String CONFIG_JNDI_NAME = "config.jndi.name";
    String CONFIG_JNDI_MEPDR_NAME = "config.jndi.mepdr.name";
    String APPLICATION_PROPERTIES = "application.properties";
    String ENCRYPTED_FLAG = "ENCRYPTED_FLAG";
    String PARAMETER_VALUE = "PARAMETER_VALUE";
    String PARAMETER_NAME = "PARAMETER_NAME";
    String REGION_CODE = "REGION_CODE";
    String SELECTOR = "SELECTOR";
    String ERROR_CODE = "ERROR_CODE";
    String ERROR_DESCRIPTION = "ERROR_DESCRIPTION";
    String ENV = "ENV";
    String REGION_STRING = "REGION";
    String CONFIG_DEVELOPER = "config.isDeveloper";
    String LOG_ARCHIVE_DAYS = "LOG_ARCHIVE_DAYS";
    String LOG_ARCHIVE_DAYS_DEFAULT = "120d";    
    
    String PPCL_DOMAIN_GROUP ="composite.service.config.domaingroup";
    String PPCL_CONFIG_SELECTOR = "composite.service.ppcl.config.selector";
    String PPCL_CONFIG_APPLICATION = "composite.service.config.application";
    String XWALK_APPLICATION = "composite.service.xwalk.application";
    String PPCL_CARRIER_CODE_FILTER = "OHC_INBOUND_CARRIER_CODE_FILTER";
    String PPCL_POLICY_STOP_DATE_FILTER = "OHC_INBOUND_POLICY_STOP_DATE_FILTER";
    String PPCL_SCOPE_OF_COVERAGE_FILTER = "OHC_INBOUND_SCOPE_OF_COVERAGE_FILTER";
    String PPCL_CARRIER_CODE_FILTER_KEY = "carrierCode";
    String PPCL_POLICY_STOP_DATE_FILTER_KEY = "policyStopDate";
    String PPCL_SCOPE_OF_COVERAGE_FILTER_KEY = "scopeOfCoverage";
    String[] FILTER_KEYS = {PPCL_CARRIER_CODE_FILTER_KEY, PPCL_POLICY_STOP_DATE_FILTER_KEY, PPCL_SCOPE_OF_COVERAGE_FILTER_KEY};
	
    String LOADER_ARCHIVE_PATH = "LOADER_ARCHIVE_PATH";
    String LOADER_ERROR_PATH = "LOADER_ERROR_PATH";
    String LOADER_INBOUND_PATH = "LOADER_INBOUND_PATH";
    String LOADER_WORKING_PATH = "LOADER_WORKING_PATH";
    String LOADER_OUTBOUND_PATH = "LOADER_OUTBOUND_PATH";
    
    String FILE_TYPE_HISDB = "HISDB";
    String FILE_TYPE_HISDB_LIKE_CALOPTIMA = "HISDB-CO";
	String FILE_TYPE_HISDB_LIKE_SM = "HISDB-SM";
	String FILE_TYPE_HISDB_LIKE_PIPE = "HISDB-PIPE";
	String FILE_TYPE_HISDB_XLS = "EXCEL";
	
	String RECORD_STATUS_RECEIVED = "Received";
	String RECORD_STATUS_ERROR = "Error";
	String RECORD_STATUS_EXTRACT = "Extracted";
	String RECORD_STATUS_WRITTEN = "Written";
	String RECORD_STATUS_SENT = "Sent";
	
    
    int DEFAULT_DB_QUERY_TIMEOUT = 7200;
    int NUMBER_OF_THREADS_FOR_SCHEDULER = 16;
    int ARCHIVE_KEEP_DAYS_DEFAULT = 30;
    
    String KPCC_DB_AUGMENT_QUERY = "select distinct EPT.region_code, CVG.employer_group_no, PPG.plan_group_name from kpccint.kpcc_ept_extract_t EPT\r\n" + 
    		"LEFT OUTER JOIN kpccint.kpcc_cvg_x_ept_extract_t CVGxEPT\r\n" + 
    		"ON CVGxEPT.patient_id = EPT.patient_id\r\n" + 
    		"LEFT OUTER JOIN kpccint.kpcc_cvg_extract_t CVG\r\n" + 
    		"ON CVG.cvg_id = CVGxEPT.cvg_id\r\n" + 
    		"LEFT OUTER JOIN kpccint.kpcc_ppg_extract_t PPG\r\n" + 
    		"ON PPG.plan_group_id = CVG.plan_group_id\r\n" + 
    		"WHERE EPT.mrn_no_format = ?";
	
}
