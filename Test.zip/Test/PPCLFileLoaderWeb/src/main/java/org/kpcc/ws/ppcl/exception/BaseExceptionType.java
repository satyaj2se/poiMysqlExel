
package org.kpcc.ws.ppcl.exception;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Following provides content for Base exception/SOAP
 * 				faults and inheritance content for Application/Business and System
 * 				level exception/SOAP faults.
 * 
 * <p>Java class for BaseExceptionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseExceptionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RegionCode" type="{http://org.kp.svc/schema/commonTypes/exceptionTypes/v1}RegionCodeEnum" minOccurs="0"/&gt;
 *         &lt;element name="CorrelationId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExceptionName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ExceptionDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="SeverityType"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://org.kp.svc/schema/commonTypes/exceptionTypes/v1}SeverityTypeEnum"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ExceptionDetail" type="{http://org.kp.svc/schema/commonTypes/exceptionTypes/v1}ExceptionDetailType"/&gt;
 *         &lt;element name="HostName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HostIPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HostType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OrigMessageId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OrigMessageTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="OtherInfo" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                   &lt;element name="Value" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseExceptionType", propOrder = {
    "regionCode",
    "correlationId",
    "exceptionName",
    "exceptionDateTime",
    "severityType",
    "exceptionDetail",
    "hostName",
    "hostIPAddress",
    "hostType",
    "origMessageId",
    "origMessageTimestamp",
    "otherInfo"
})
@XmlSeeAlso({
    SystemExceptionType.class,
    BusinessExceptionType.class
})
public abstract class BaseExceptionType {

    @XmlElement(name = "RegionCode")
    protected RegionCodeEnum regionCode;
    @XmlElement(name = "CorrelationId")
    protected String correlationId;
    @XmlElement(name = "ExceptionName", required = true)
    protected String exceptionName;
    @XmlElement(name = "ExceptionDateTime")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar exceptionDateTime;
    @XmlElement(name = "SeverityType", required = true)
    protected SeverityTypeEnum severityType;
    @XmlElement(name = "ExceptionDetail", required = true)
    protected ExceptionDetailType exceptionDetail;
    @XmlElement(name = "HostName")
    protected String hostName;
    @XmlElement(name = "HostIPAddress")
    protected String hostIPAddress;
    @XmlElement(name = "HostType")
    protected String hostType;
    @XmlElement(name = "OrigMessageId")
    protected String origMessageId;
    @XmlElement(name = "OrigMessageTimestamp")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar origMessageTimestamp;
    @XmlElement(name = "OtherInfo")
    protected List<BaseExceptionType.OtherInfo> otherInfo;

    /**
     * Gets the value of the regionCode property.
     * 
     * @return
     *     possible object is
     *     {@link RegionCodeEnum }
     *     
     */
    public RegionCodeEnum getRegionCode() {
        return regionCode;
    }

    /**
     * Sets the value of the regionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link RegionCodeEnum }
     *     
     */
    public void setRegionCode(RegionCodeEnum value) {
        this.regionCode = value;
    }

    /**
     * Gets the value of the correlationId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrelationId() {
        return correlationId;
    }

    /**
     * Sets the value of the correlationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrelationId(String value) {
        this.correlationId = value;
    }

    /**
     * Gets the value of the exceptionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionName() {
        return exceptionName;
    }

    /**
     * Sets the value of the exceptionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionName(String value) {
        this.exceptionName = value;
    }

    /**
     * Gets the value of the exceptionDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getExceptionDateTime() {
        return exceptionDateTime;
    }

    /**
     * Sets the value of the exceptionDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setExceptionDateTime(XMLGregorianCalendar value) {
        this.exceptionDateTime = value;
    }

    /**
     * Gets the value of the severityType property.
     * 
     * @return
     *     possible object is
     *     {@link SeverityTypeEnum }
     *     
     */
    public SeverityTypeEnum getSeverityType() {
        return severityType;
    }

    /**
     * Sets the value of the severityType property.
     * 
     * @param value
     *     allowed object is
     *     {@link SeverityTypeEnum }
     *     
     */
    public void setSeverityType(SeverityTypeEnum value) {
        this.severityType = value;
    }

    /**
     * Gets the value of the exceptionDetail property.
     * 
     * @return
     *     possible object is
     *     {@link ExceptionDetailType }
     *     
     */
    public ExceptionDetailType getExceptionDetail() {
        return exceptionDetail;
    }

    /**
     * Sets the value of the exceptionDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExceptionDetailType }
     *     
     */
    public void setExceptionDetail(ExceptionDetailType value) {
        this.exceptionDetail = value;
    }

    /**
     * Gets the value of the hostName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostName() {
        return hostName;
    }

    /**
     * Sets the value of the hostName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostName(String value) {
        this.hostName = value;
    }

    /**
     * Gets the value of the hostIPAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostIPAddress() {
        return hostIPAddress;
    }

    /**
     * Sets the value of the hostIPAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostIPAddress(String value) {
        this.hostIPAddress = value;
    }

    /**
     * Gets the value of the hostType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostType() {
        return hostType;
    }

    /**
     * Sets the value of the hostType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostType(String value) {
        this.hostType = value;
    }

    /**
     * Gets the value of the origMessageId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigMessageId() {
        return origMessageId;
    }

    /**
     * Sets the value of the origMessageId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigMessageId(String value) {
        this.origMessageId = value;
    }

    /**
     * Gets the value of the origMessageTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getOrigMessageTimestamp() {
        return origMessageTimestamp;
    }

    /**
     * Sets the value of the origMessageTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setOrigMessageTimestamp(XMLGregorianCalendar value) {
        this.origMessageTimestamp = value;
    }

    /**
     * Gets the value of the otherInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the otherInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOtherInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BaseExceptionType.OtherInfo }
     * 
     * 
     */
    public List<BaseExceptionType.OtherInfo> getOtherInfo() {
        if (otherInfo == null) {
            otherInfo = new ArrayList<BaseExceptionType.OtherInfo>();
        }
        return this.otherInfo;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *         &lt;element name="Value" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "name",
        "value"
    })
    public static class OtherInfo {

        @XmlElement(name = "Name", required = true)
        protected String name;
        @XmlElement(name = "Value", required = true)
        protected String value;

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

    }

}
