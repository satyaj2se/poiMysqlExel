package org.kpcc.ws.ppcl.file.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.kpcc.ws.ppcl.constants.PPCLConstant;
import org.kpcc.ws.ppcl.dto.PPCLHISDBBenIfoStageDTO;
import org.kpcc.ws.ppcl.dto.PPCLHISDBCarrierStageDTO;
import org.kpcc.ws.ppcl.properties.ApplicationProperties;
import org.kpcc.ws.ppcl.repo.PPCLHISDBBenInfoStageRepo;
import org.kpcc.ws.ppcl.repo.PPCLHISDBCarrierRepo;
import org.kpcc.ws.ppcl.utils.DataValidatorUtil;
import org.kpcc.ws.ppcl.utils.DatabaseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/*
  @author T978515
*/
@Component
public class ProcessExcelFile {
	private static Logger logger = LogManager.getLogger(ProcessExcelFile.class);

	@Autowired
	private PPCLHISDBBenInfoStageRepo benInfoRepo;

	@Autowired
	private PPCLHISDBCarrierRepo ohcStageRepo;

	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * This method for processing the excel
	 * @param lzMap
	 * @param lzFile
	 * @return
	 * @throws InvalidFormatException
	 */
	
	public String processExcelData(Map<String, String> lzMap, File lzFile) throws InvalidFormatException {
		logger.info("ProcessExcelFile : Excel file data processing initiated...");
		String status = "";
		
		String workingPath = lzMap.get(PPCLConstant.LOADER_WORKING_PATH);
		String errorPath = lzMap.get(PPCLConstant.LOADER_ERROR_PATH);

		List<PPCLHISDBCarrierStageDTO> ohcSegList = new ArrayList<>();

		if (lzFile != null) {
			try (BufferedReader br = Files.newBufferedReader(Paths.get(lzFile.getPath()))) {

				// Workbook workbook = new XSSFWorkbook(lzFile); //In case of xls extension

				XSSFWorkbook wb = new XSSFWorkbook(lzFile);
				XSSFSheet sheet = wb.getSheetAt(0); // creating a Sheet object to retrieve object
				Iterator<Row> itr = sheet.iterator(); // iterating over excel file

				int count = 0;
				itr.next(); // skip the header row

				PPCLHISDBBenIfoStageDTO benInfo = null;
				PPCLHISDBCarrierStageDTO carStage = null;

				while (itr.hasNext()) {
					Row nextRow = itr.next();
					Iterator<Cell> cellIterator = nextRow.cellIterator();

					benInfo = new PPCLHISDBBenIfoStageDTO();
					carStage = new PPCLHISDBCarrierStageDTO();

					while (cellIterator.hasNext()) {

						Cell nextCell = cellIterator.next();

						int columnIndex = nextCell.getColumnIndex();

						switch (columnIndex) {
						case 0:
							if (nextCell.getCellType() == CellType.NUMERIC) {
								String str = NumberToTextConverter.toText(nextCell.getNumericCellValue());
								benInfo.setLogId((Integer.parseInt(str)));
							} else if (nextCell.getCellType() == CellType.STRING) {
								String logid = nextCell.getStringCellValue();
								benInfo.setLogId(Integer.parseInt(logid));

							}
							logger.info("****LOG_ID for String***" + benInfo.getLogId());
							break;

						case 1:
							benInfo.setFileName(nextCell.getStringCellValue());
							logger.info("***FILE_NAME****" + benInfo.getFileName());
							break;
						case 2:
							String medids = (nextCell.getCellType() == CellType.NUMERIC)
									? NumberToTextConverter.toText(nextCell.getNumericCellValue())
									: nextCell.getStringCellValue();
							benInfo.setMedsId(medids);
							carStage.setMedsId(medids);
							logger.info("***MEDS_ID*STRING***" + benInfo.getMedsId());
							break;
						case 3:
							String nbr = (nextCell.getCellType() == CellType.NUMERIC)
									? NumberToTextConverter.toText(nextCell.getNumericCellValue())
									: nextCell.getStringCellValue();
							benInfo.setNbrOfInsuranceSegments(nbr);
							logger.info("***INSURANCE SEGMENT NUMBER****" + benInfo.getNbrOfInsuranceSegments());
							break;
						case 4:
							benInfo.setBeneficiaryPhoneNbr(nextCell.getStringCellValue());
							logger.info("***BENEFICERY PHONE NUmber****" + benInfo.getBeneficiaryPhoneNbr());
							break;
						case 5:
							benInfo.setCountryWorkerPhoneNbr(nextCell.getStringCellValue());
							logger.info("***COUNTTRY PHONE NUmber****" + benInfo.getCountryWorkerPhoneNbr());
							break;
						case 6:
							benInfo.setHiqMailingDate(nextCell.getStringCellValue());
							logger.info("***HIQ6 MAILING Date****" + benInfo.getHiqMailingDate());
							break;
						case 7:
							benInfo.setOhcLetterMailingDate(nextCell.getStringCellValue());
							logger.info("***OHC MAILING Date****" + benInfo.getOhcLetterMailingDate());
							break;
						case 8:
							benInfo.setFormLetterMailingDate(nextCell.getStringCellValue());
							logger.info("***Form MAILING Date****" + benInfo.getOhcLetterMailingDate());
							break;
						case 9:
							String IVDMemberID = nextCell.getStringCellValue();
							benInfo.setIvdMemberId(IVDMemberID);
							break;
						case 10:
							String Filler1 = nextCell.getStringCellValue();
							benInfo.setFiller1(Filler1);
							break;
						case 11:
							String HIQ6155AFlag = nextCell.getStringCellValue();
							benInfo.setHiqFlag(HIQ6155AFlag);
							break;
						case 12:
							String pendingOHC = nextCell.getStringCellValue();
							benInfo.setPendingOHC(pendingOHC);
							break;
						case 13:
							String MEDSCurrentYearMonth = nextCell.getStringCellValue();
							benInfo.setMedsCurrentDate(MEDSCurrentYearMonth);
							break;
						case 14:
							String Filler2 = nextCell.getStringCellValue();
							benInfo.setFiller2(Filler2);
							break;
						case 15:
							String insuranceSegmentNumber = nextCell.getStringCellValue();
							carStage.setInsuranceStatusCode(insuranceSegmentNumber);
							break;
						case 16:
							String carrierCode = nextCell.getStringCellValue();
							carStage.setCarrierCode(carrierCode);
							break;
						case 17:
							String policyNumber = nextCell.getStringCellValue();
							carStage.setpolicyNumber(policyNumber);
							break;
						case 18:
							String SegmentType = nextCell.getStringCellValue();
							carStage.setSegmentTyp(SegmentType);
							break;
						case 19:
							String ScopeofCoverage = nextCell.getStringCellValue();
							carStage.setScopOfCoverage(ScopeofCoverage);
							break;
						case 20:
							String policyStartDate = nextCell.getStringCellValue();
							carStage.setPolicyStartDate(policyStartDate);
							break;
						case 21:
							String policyStopDate = nextCell.getStringCellValue();
							carStage.setPolicyStopDate(policyStopDate);
							break;
						case 22:
							String lastChangeDate = nextCell.getStringCellValue();
							carStage.setLastChangeDate(lastChangeDate);
							break;
						case 23:
							String sourceofChange = nextCell.getStringCellValue();
							carStage.setSourceOfChange(sourceofChange);
							break;
						case 24:
							String transactionType = nextCell.getStringCellValue();
							carStage.setTransactionTyp(transactionType);
							break;
						case 25:
							String operatorId = nextCell.getStringCellValue();
							carStage.setOperatorId(operatorId);
							break;
						case 26:
							String Filler3 = nextCell.getStringCellValue();
							carStage.setFiller1(Filler3);
							break;
						case 27:
							String absentParentInsuranceFlag = nextCell.getStringCellValue();
							carStage.setAbsentParentInsuranceFlag(absentParentInsuranceFlag);
							break;
						case 28:
							String insuranceStatusCode = nextCell.getStringCellValue();
							carStage.setInsuranceStatusCode(insuranceStatusCode);
							break;
						case 29:
							String relationshiptoPolicyHolder = nextCell.getStringCellValue();
							carStage.setRelationShipToPolicyHolder(relationshiptoPolicyHolder);
							break;
						case 30:
							String dependentCoverageAvailable = nextCell.getStringCellValue();
							carStage.setDependentCoverageAvilable(dependentCoverageAvailable);
							break;
						case 31:
							String iexSourceOfCoverage = nextCell.getStringCellValue();
							carStage.setIexSourceOfCoverage(iexSourceOfCoverage);
							break;
						case 32:
							String terminationReason = nextCell.getStringCellValue();
							carStage.setTerminationReason(terminationReason);
							break;
						case 33:
							String followUpFileFlag = nextCell.getStringCellValue();
							carStage.setFollowUpFlag(followUpFileFlag);
							break;
						case 34:
							String policyHolderSSN = nextCell.getStringCellValue();
							carStage.setPolicyHolderSSN(policyHolderSSN);
							break;
						case 35:
							String policyHolderLastNM = nextCell.getStringCellValue();
							carStage.setPolicyHolderLastNM(policyHolderLastNM);
							break;
						case 36:
							String policyHolderFirstName = nextCell.getStringCellValue();
							carStage.setPolicyHolderFirstNM(policyHolderFirstName);
							break;
						case 37:
							String policyHolderMiddleInitial = nextCell.getStringCellValue();
							carStage.setPolicyHolderMiddleInitial(policyHolderMiddleInitial);
							break;
						case 38:
							String policyHolderAddressLine1 = nextCell.getStringCellValue();
							carStage.setPolicyHolderAddrLine1(policyHolderAddressLine1);
							break;
						case 39:
							String policyHolderAddressLine2 = nextCell.getStringCellValue();
							carStage.setPolicyHolderAddrLine2(policyHolderAddressLine2);
							break;
						case 40:
							String policyHolderCityState = nextCell.getStringCellValue();
							carStage.setPolicyHolderCityState(policyHolderCityState);
							break;
						case 41:
							String policyHolderZipCode = nextCell.getStringCellValue();
							carStage.setPolicyHolderZipCD(policyHolderZipCode);
							break;
						case 42:
							String policyHolderZip4 = nextCell.getStringCellValue();
							carStage.setPolicyHolderZip4(policyHolderZip4);
							break;
						case 43:
							String policyHolderPhoneNumber = nextCell.getStringCellValue();
							carStage.setPolicyHolderPhoneNbr(policyHolderPhoneNumber);
							break;
						case 44:
							String groupEmployerName = nextCell.getStringCellValue();
							carStage.setGroupEmployerName(groupEmployerName);
							break;
						case 45:
							String groupEmployerNumber = nextCell.getStringCellValue();
							carStage.setGroupEmployerNumber(groupEmployerNumber);
							break;
						case 46:
							String groupEmployerAddressLine1 = nextCell.getStringCellValue();
							carStage.setGroupEmployerAddrLine1(groupEmployerAddressLine1);
							break;
						case 47:
							String groupEmployerAddressLine2 = nextCell.getStringCellValue();
							carStage.setGroupEmployerAddrLine2(groupEmployerAddressLine2);
							break;
						case 48:
							String groupEmployerCityState = nextCell.getStringCellValue();
							carStage.setGroupEmployerCityState(groupEmployerCityState);
							break;
						case 49:
							String groupEmployerZipCode = nextCell.getStringCellValue();
							carStage.setGroupEmployerZipCD(groupEmployerZipCode);
							break;
						case 50:
							String groupEmployerZip4 = nextCell.getStringCellValue();
							carStage.setGroupEmployerZip4(groupEmployerZip4);
							break;
						case 51:
							String groupEmployerPhoneNumber = nextCell.getStringCellValue();
							carStage.setGroupEmployerPhoneNbr(groupEmployerPhoneNumber);
							break;
						case 52:
							String unionName = nextCell.getStringCellValue();
							carStage.setUnionName(unionName);
							break;
						case 53:
							String unionLocalNumber = nextCell.getStringCellValue();
							carStage.setUnionLocalNumber(unionLocalNumber);
							break;
						case 54:
							String bountyAddDate = nextCell.getStringCellValue();
							carStage.setBountyAddDate(bountyAddDate);
							break;
						case 55:
							String bountyAddSource = nextCell.getStringCellValue();
							carStage.setBountyAddSource(bountyAddSource);
							break;
						case 56:
							String bountyAddCountyId = nextCell.getStringCellValue();
							carStage.setBountyAddCountyId(bountyAddCountyId);
							break;
						case 57:
							String bountyAddEligWorkerCode = nextCell.getStringCellValue();
							carStage.setBountyAddEligWorkerCD(bountyAddEligWorkerCode);
							break;
						case 58:
							String bountyAddDistrict = nextCell.getStringCellValue();
							carStage.setBountyAddDistrict(bountyAddDistrict);
							break;
						case 59:
							String bountyStatus = nextCell.getStringCellValue();
							carStage.setBountyStatus(bountyStatus);
							break;
						case 60:
							String planId = nextCell.getStringCellValue();
							carStage.setPlanId(planId);
							break;
						case 61:
							String typeId = nextCell.getStringCellValue();
							carStage.setTypeId(typeId);
							break;
						case 62:
							String Filler4 = nextCell.getStringCellValue();
							carStage.setFiller2(Filler4);
							break;
						default:
							logger.info("File is processed");

						}

						String regionCode = ApplicationProperties.getRegion();
						long now = System.currentTimeMillis();
						Timestamp timestamp = new Timestamp(now);
						
						benInfo.setRecordStatus("inbound");
						// TODO with actual recieved fileId.
						
						benInfo.setRcvdFileId(5l);
						benInfo.setInsertTimestamp(timestamp);
						benInfo.setUpdateTimeStamp(timestamp);
						benInfo.setInsertUser(DatabaseUtils.getDatabseUsername());
						benInfo.setUpdateUser(DatabaseUtils.getDatabseUsername());
						benInfo.setRegionCode(regionCode);
						benInfoRepo.save(benInfo);

						carStage.setRegionCode(regionCode);
						carStage.setRecordStatus("inbound");
						carStage.setRcvdFileId(5l); //TODO to be replaced with recieved file id.
						carStage.setInsertTimestamp(timestamp);
						carStage.setUpdateTimeStamp(timestamp);

						carStage.setInsertUser(DatabaseUtils.getDatabseUsername());
						carStage.setUpdateUser(DatabaseUtils.getDatabseUsername());
						carStage.setRcvdOhcBeninfoId(benInfo.getRcvdOhcBeninfoId());
						ohcSegList.add(carStage);

					}

				}
				ohcStageRepo.saveAll(ohcSegList);
				wb.close();
				status = "Success";
			} catch (IOException ie) {
				logger.error("Error occured while processing the data : " + ie.getMessage());
				status = "Failed";
				moveFile(lzFile, errorPath);
			} catch (Exception e) {
				logger.error("Error occured while processing the data : " + e.getMessage());
				moveFile(lzFile, errorPath);
				status = "Failed";
				
			}
		} else {
			status = "File not available";
		}
		if(status.equalsIgnoreCase("Success")) {
			moveFile(lzFile, workingPath);
		} else {
			moveFile(lzFile, errorPath);
		}
		return status;
	}

	
	/**
	 * Moving the files if the file contains some error.
	 * @param lzFile
	 * @param toPath
	 * @return
	 */
	private boolean moveFile(File lzFile, String toPath) {
		Path tempWork = null;
		try {
			String fileName = lzFile.getName();
			tempWork = Files.move(Paths.get(lzFile.getPath()), Paths.get(toPath.concat("\\").concat(fileName)),
					StandardCopyOption.REPLACE_EXISTING);

			if (tempWork != null) {
				logger.info("File renamed and moved successfully to : " + toPath);
			} else {
				logger.info("Failed to move the file");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return (tempWork != null);
	}
}
