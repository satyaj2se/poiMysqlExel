package org.kpcc.ws.ppcl.repo;

import org.kpcc.ws.ppcl.dto.PPCLPartnerDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface PPCLPartnerRepo extends JpaRepository<PPCLPartnerDTO,Long> {

}
