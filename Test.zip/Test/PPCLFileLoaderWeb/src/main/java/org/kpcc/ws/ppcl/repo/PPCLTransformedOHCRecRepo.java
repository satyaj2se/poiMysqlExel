/**
 * 
 */
package org.kpcc.ws.ppcl.repo;

import org.kpcc.ws.ppcl.dto.PPCLTransformedOHCRecDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author S492749
 *
 */
@Component
@Transactional
public interface PPCLTransformedOHCRecRepo extends JpaRepository<PPCLTransformedOHCRecDTO, Long> {

}
