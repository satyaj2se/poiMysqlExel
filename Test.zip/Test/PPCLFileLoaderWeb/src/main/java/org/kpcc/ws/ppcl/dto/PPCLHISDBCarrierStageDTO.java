
package org.kpcc.ws.ppcl.dto;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "PPCL_HISDB_CARRIER_STG_T")
public class PPCLHISDBCarrierStageDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "RCVD_OHC_CARRIER_ID")
	Long rcvdOhcCarrierId;

	@Column(name = "RCVD_FILE_ID")
	Long rcvdFileId;
	@Column(name = "RCVD_OHC_BENINFO_ID")
	Long rcvdOhcBeninfoId;
	/*
	 * Added segment as a part of HISDBLIKE file read
	 */
	@Column(name = "SEGMENT")
	String segment;
	@Column(name = "REGION_CODE")
	String regionCode;
	@Column(name = "RECORD_STATUS")
	String recordStatus;
	@Column(name = "MEDS_ID")
	String medsId;

	@Column(name = "CARRIER_CODE")
	String carrierCode;
	@Column(name = "POLICY_NUMBER")
	String policyNumber;

	@Column(name = "SEGMENT_TYP")
	String segmentTyp;

	@Column(name = "SCOPE_OF_COVERAGE")
	String scopOfCoverage;

	@Column(name = "TRANSACTION_TYP")
	String transactionTyp;

	@Column(name = "OPERATOR_ID")
	String operatorId;

	@Column(name = "ABSENT_PARENT_INSURANCE_FLAG")
	String absentParentInsuranceFlag;

	@Column(name = "INSURANCE_STATUS_CODE")
	String insuranceStatusCode;

	@Column(name = "RELATIONSHIP_TO_POLICY_HOLDER")
	String relationShipToPolicyHolder;

	@Column(name = "DEPENDENT_COVERAGE_AVILABLE")
	String dependentCoverageAvilable;

	@Column(name = "IEX_SOURCE_OF_COVERAGE")
	String iexSourceOfCoverage;

	@Column(name = "TERMINATION_REASON")
	String terminationReason;

	@Column(name = "FOLLOW_UP_FLAG")
	String followUpFlag;

	@Column(name = "POLICY_HOLDER_SSN")
	String policyHolderSSN;
	@Column(name = "POLICY_HOLDER_PHONE_NBR")
	String policyHolderPhoneNbr;
	@Column(name = "GROUP_EMPLOYER_NAME")
	String groupEmployerName;
	@Column(name = "GROUP_EMPLOYER_NUMBER")
	String groupEmployerNumber;

	@Column(name = "GROUP_EMPLOYER_PHONE_NBR")
	String groupEmployerPhoneNbr;

	@Column(name = "UNION_NAME")
	String unionName;

	@Column(name = "UNION_LOCAL_NUMBER")
	String unionLocalNumber;

	@Column(name = "PLAN_ID")
	String planId;

	@Column(name = "TYPE_ID")
	String typeId;

	@Column(name = "POLICY_START_DATE")
	String policyStartDate;

	@Column(name = "POLICY_STOP_DATE")
	String policyStopDate;

	@Column(name = "LAST_CHANGE_DATE")
	String lastChangeDate;

	@Column(name = "SOURCE_OF_CHANGE")
	String sourceOfChange;

	@Column(name = "FILLER1")
	String filler1;

	@Column(name = "POLICY_HOLDER_LAST_NM")
	String policyHolderLastNM;

	@Column(name = "POLICY_HOLDER_FIRST_NM")
	String policyHolderFirstNM;

	@Column(name = "POLICY_HOLDER_MIDDILE_INITIAL")
	String policyHolderMiddleInitial;
	@Column(name = "POLICY_HOLDER_ADDR_LINE1")
	String policyHolderAddrLine1;
	@Column(name = "POLICY_HOLDER_ADDR_LINE2")
	String policyHolderAddrLine2;
	@Column(name = "POLICY_HOLDER_CITY_STATE")
	String policyHolderCityState;
	@Column(name = "POLICY_HOLDER_ZIP_CD")
	String policyHolderZipCD;
	@Column(name = "POLICY_HOLDER_ZIP4")
	String policyHolderZip4;
	@Column(name = "GROUP_EMPLOYER_ADDR_LINE1")
	String groupEmployerAddrLine1;
	@Column(name = "GROUP_EMPLOYER_ADDR_LINE2")
	String groupEmployerAddrLine2;
	@Column(name = "GROUP_EMPLOYER_CITY_STATE")
	String groupEmployerCityState;
	@Column(name = "GROUP_EMPLOYER_ZIP_CD")
	String groupEmployerZipCD;
	@Column(name = "GROUP_EMPLOYER_ZIP4")
	String groupEmployerZip4;
	@Column(name = "BOUNTY_ADD_DATE")
	String bountyAddDate;

	@Column(name = "BOUNTY_ADD_SOURCE")
	String bountyAddSource;
	@Column(name = "BOUNTY_ADD_COUNTY_ID")
	String bountyAddCountyId;
	@Column(name = "BOUNTY_ADD_ELIG_WORKER_CD")
	String bountyAddEligWorkerCD;
	@Column(name = "BOUNTY_ADD_DISTRICT")
	String bountyAddDistrict;
	@Column(name = "BOUNTY_STATUS")
	String bountyStatus;
	@Column(name = "FILLER2")
	String filler2;

	@Column(name = "INSERT_TIMESTAMP")
	Timestamp insertTimestamp;
	@Column(name = "INSERT_USER")
	String insertUser;
	@Column(name = "UPDATE_TIMESTAMP")
	Timestamp updateTimeStamp;
	@Column(name = "UPDATE_USER")
	String updateUser;

	@Column(name = "INSERT_PROCESS")
	String insertProcess;
	@Column(name = "INSERT_PROCESS_ID")
	Long insertProcessId;
	@Column(name = "UPDATE_PROCESS")
	String updateProcess;
	@Column(name = "UPDATE_PROCESS_ID")
	Long updateProcessId;

	public Long getRcvdOhcCarrierId() {
		return rcvdOhcCarrierId;
	}

	public void setRcvdOhcCarrierId(Long rcvdOhcCarrierId) {
		this.rcvdOhcCarrierId = rcvdOhcCarrierId;
	}

	public Long getRcvdFileId() {
		return rcvdFileId;
	}

	public void setRcvdFileId(Long rcvdFileId) {
		this.rcvdFileId = rcvdFileId;
	}

	public Long getRcvdOhcBeninfoId() {
		return rcvdOhcBeninfoId;
	}

	public void setRcvdOhcBeninfoId(Long rcvdOhcBeninfoId) {
		this.rcvdOhcBeninfoId = rcvdOhcBeninfoId;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public String getMedsId() {
		return medsId;
	}

	public void setMedsId(String medsId) {
		this.medsId = medsId;
	}

	public String getCarrierCode() {
		return carrierCode;
	}

	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}

	public String getpolicyNumber() {
		return policyNumber;
	}

	public void setpolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getSegmentTyp() {
		return segmentTyp;
	}

	public void setSegmentTyp(String segmentTyp) {
		this.segmentTyp = segmentTyp;
	}

	public String getScopOfCoverage() {
		return scopOfCoverage;
	}

	public void setScopOfCoverage(String scopOfCoverage) {
		this.scopOfCoverage = scopOfCoverage;
	}

	public String getTransactionTyp() {
		return transactionTyp;
	}

	public void setTransactionTyp(String transactionTyp) {
		this.transactionTyp = transactionTyp;
	}

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public String getAbsentParentInsuranceFlag() {
		return absentParentInsuranceFlag;
	}

	public void setAbsentParentInsuranceFlag(String absentParentInsuranceFlag) {
		this.absentParentInsuranceFlag = absentParentInsuranceFlag;
	}

	public String getInsuranceStatusCode() {
		return insuranceStatusCode;
	}

	public void setInsuranceStatusCode(String insuranceStatusCode) {
		this.insuranceStatusCode = insuranceStatusCode;
	}

	public String getRelationShipToPolicyHolder() {
		return relationShipToPolicyHolder;
	}

	public void setRelationShipToPolicyHolder(String relationShipToPolicyHolder) {
		this.relationShipToPolicyHolder = relationShipToPolicyHolder;
	}

	public String getDependentCoverageAvilable() {
		return dependentCoverageAvilable;
	}

	public void setDependentCoverageAvilable(String dependentCoverageAvilable) {
		this.dependentCoverageAvilable = dependentCoverageAvilable;
	}

	public String getIexSourceOfCoverage() {
		return iexSourceOfCoverage;
	}

	public void setIexSourceOfCoverage(String iexSourceOfCoverage) {
		this.iexSourceOfCoverage = iexSourceOfCoverage;
	}

	public String getTerminationReason() {
		return terminationReason;
	}

	public void setTerminationReason(String terminationReason) {
		this.terminationReason = terminationReason;
	}

	public String getFollowUpFlag() {
		return followUpFlag;
	}

	public void setFollowUpFlag(String followUpFlag) {
		this.followUpFlag = followUpFlag;
	}

	public String getPolicyHolderSSN() {
		return policyHolderSSN;
	}

	public void setPolicyHolderSSN(String policyHolderSSN) {
		this.policyHolderSSN = policyHolderSSN;
	}

	public String getPolicyHolderPhoneNbr() {
		return policyHolderPhoneNbr;
	}

	public void setPolicyHolderPhoneNbr(String policyHolderPhoneNbr) {
		this.policyHolderPhoneNbr = policyHolderPhoneNbr;
	}

	public String getGroupEmployerName() {
		return groupEmployerName;
	}

	public void setGroupEmployerName(String groupEmployerName) {
		this.groupEmployerName = groupEmployerName;
	}

	public String getGroupEmployerNumber() {
		return groupEmployerNumber;
	}

	public void setGroupEmployerNumber(String groupEmployerNumber) {
		this.groupEmployerNumber = groupEmployerNumber;
	}

	public String getGroupEmployerPhoneNbr() {
		return groupEmployerPhoneNbr;
	}

	public void setGroupEmployerPhoneNbr(String groupEmployerPhoneNbr) {
		this.groupEmployerPhoneNbr = groupEmployerPhoneNbr;
	}

	public String getUnionName() {
		return unionName;
	}

	public void setUnionName(String unionName) {
		this.unionName = unionName;
	}

	public String getUnionLocalNumber() {
		return unionLocalNumber;
	}

	public void setUnionLocalNumber(String unionLocalNumber) {
		this.unionLocalNumber = unionLocalNumber;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	public String getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public String getPolicyStopDate() {
		return policyStopDate;
	}

	public void setPolicyStopDate(String policyStopDate) {
		this.policyStopDate = policyStopDate;
	}

	public String getLastChangeDate() {
		return lastChangeDate;
	}

	public void setLastChangeDate(String lastChangeDate) {
		this.lastChangeDate = lastChangeDate;
	}

	public String getSourceOfChange() {
		return sourceOfChange;
	}

	public void setSourceOfChange(String sourceOfChange) {
		this.sourceOfChange = sourceOfChange;
	}

	public String getFiller1() {
		return filler1;
	}

	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}

	public String getPolicyHolderLastNM() {
		return policyHolderLastNM;
	}

	public void setPolicyHolderLastNM(String policyHolderLastNM) {
		this.policyHolderLastNM = policyHolderLastNM;
	}

	public String getPolicyHolderFirstNM() {
		return policyHolderFirstNM;
	}

	public void setPolicyHolderFirstNM(String policyHolderFirstNM) {
		this.policyHolderFirstNM = policyHolderFirstNM;
	}

	public String getPolicyHolderMiddleInitial() {
		return policyHolderMiddleInitial;
	}

	public void setPolicyHolderMiddleInitial(String policyHolderMiddleInitial) {
		this.policyHolderMiddleInitial = policyHolderMiddleInitial;
	}

	public String getPolicyHolderAddrLine1() {
		return policyHolderAddrLine1;
	}

	public void setPolicyHolderAddrLine1(String policyHolderAddrLine1) {
		this.policyHolderAddrLine1 = policyHolderAddrLine1;
	}

	public String getPolicyHolderAddrLine2() {
		return policyHolderAddrLine2;
	}

	public void setPolicyHolderAddrLine2(String policyHolderAddrLine2) {
		this.policyHolderAddrLine2 = policyHolderAddrLine2;
	}

	public String getPolicyHolderCityState() {
		return policyHolderCityState;
	}

	public void setPolicyHolderCityState(String policyHolderCityState) {
		this.policyHolderCityState = policyHolderCityState;
	}

	public String getPolicyHolderZipCD() {
		return policyHolderZipCD;
	}

	public void setPolicyHolderZipCD(String policyHolderZipCD) {
		this.policyHolderZipCD = policyHolderZipCD;
	}

	public String getPolicyHolderZip4() {
		return policyHolderZip4;
	}

	public void setPolicyHolderZip4(String policyHolderZip4) {
		this.policyHolderZip4 = policyHolderZip4;
	}

	public String getGroupEmployerAddrLine1() {
		return groupEmployerAddrLine1;
	}

	public void setGroupEmployerAddrLine1(String groupEmployerAddrLine1) {
		this.groupEmployerAddrLine1 = groupEmployerAddrLine1;
	}

	public String getGroupEmployerAddrLine2() {
		return groupEmployerAddrLine2;
	}

	public void setGroupEmployerAddrLine2(String groupEmployerAddrLine2) {
		this.groupEmployerAddrLine2 = groupEmployerAddrLine2;
	}

	public String getGroupEmployerCityState() {
		return groupEmployerCityState;
	}

	public void setGroupEmployerCityState(String groupEmployerCityState) {
		this.groupEmployerCityState = groupEmployerCityState;
	}

	public String getGroupEmployerZipCD() {
		return groupEmployerZipCD;
	}

	public void setGroupEmployerZipCD(String groupEmployerZipCD) {
		this.groupEmployerZipCD = groupEmployerZipCD;
	}

	public String getGroupEmployerZip4() {
		return groupEmployerZip4;
	}

	public void setGroupEmployerZip4(String groupEmployerZip4) {
		this.groupEmployerZip4 = groupEmployerZip4;
	}

	public String getBountyAddDate() {
		return bountyAddDate;
	}

	public void setBountyAddDate(String bountyAddDate) {
		this.bountyAddDate = bountyAddDate;
	}

	public String getBountyAddSource() {
		return bountyAddSource;
	}

	public void setBountyAddSource(String bountyAddSource) {
		this.bountyAddSource = bountyAddSource;
	}

	public String getBountyAddCountyId() {
		return bountyAddCountyId;
	}

	public void setBountyAddCountyId(String bountyAddCountyId) {
		this.bountyAddCountyId = bountyAddCountyId;
	}

	public String getBountyAddEligWorkerCD() {
		return bountyAddEligWorkerCD;
	}

	public void setBountyAddEligWorkerCD(String bountyAddEligWorkerCD) {
		this.bountyAddEligWorkerCD = bountyAddEligWorkerCD;
	}

	public String getBountyAddDistrict() {
		return bountyAddDistrict;
	}

	public void setBountyAddDistrict(String bountyAddDistrict) {
		this.bountyAddDistrict = bountyAddDistrict;
	}

	public String getBountyStatus() {
		return bountyStatus;
	}

	public void setBountyStatus(String bountyStatus) {
		this.bountyStatus = bountyStatus;
	}

	public String getFiller2() {
		return filler2;
	}

	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public Timestamp getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Timestamp insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public String getInsertUser() {
		return insertUser;
	}

	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}

	public Timestamp getUpdateTimeStamp() {
		return updateTimeStamp;
	}

	public void setUpdateTimeStamp(Timestamp updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getInsertProcess() {
		return insertProcess;
	}

	public void setInsertProcess(String insertProcess) {
		this.insertProcess = insertProcess;
	}

	public Long getInsertProcessId() {
		return insertProcessId;
	}

	public void setInsertProcessId(Long insertProcessId) {
		this.insertProcessId = insertProcessId;
	}

	public String getUpdateProcess() {
		return updateProcess;
	}

	public void setUpdateProcess(String updateProcess) {
		this.updateProcess = updateProcess;
	}

	public Long getUpdateProcessId() {
		return updateProcessId;
	}

	public void setUpdateProcessId(Long updateProcessId) {
		this.updateProcessId = updateProcessId;
	}

	@Override
	public String toString() {
		return "PPCLHISDBCarrierStageDTO [rcvdOhcCarrierId=" + rcvdOhcCarrierId + ", rcvdFileId=" + rcvdFileId
				+ ", rcvdOhcBeninfoId=" + rcvdOhcBeninfoId + ", regionCode=" + regionCode + ", recordStatus="
				+ recordStatus + ", medsId=" + medsId + ",segment=" + segment + ", carrierCode=" + carrierCode
				+ ", policyNumber=" + policyNumber + ", segmentTyp=" + segmentTyp + ", scopOfCoverage=" + scopOfCoverage
				+ ", transactionTyp=" + transactionTyp + ", operatorId=" + operatorId + ", absentParentInsuranceFlag="
				+ absentParentInsuranceFlag + ", insuranceStatusCode=" + insuranceStatusCode
				+ ", relationShipToPolicyHolder=" + relationShipToPolicyHolder + ", dependentCoverageAvilable="
				+ dependentCoverageAvilable + ", iexSourceOfCoverage=" + iexSourceOfCoverage + ", terminationReason="
				+ terminationReason + ", followUpFlag=" + followUpFlag + ", policyHolderSSN=" + policyHolderSSN
				+ ", policyHolderPhoneNbr=" + policyHolderPhoneNbr + ", groupEmployerName=" + groupEmployerName
				+ ", groupEmployerNumber=" + groupEmployerNumber + ", groupEmployerPhoneNbr=" + groupEmployerPhoneNbr
				+ ", unionName=" + unionName + ", unionLocalNumber=" + unionLocalNumber + ", planId=" + planId
				+ ", typeId=" + typeId + ", policyStartDate=" + policyStartDate + ", policyStopDate=" + policyStopDate
				+ ", lastChangeDate=" + lastChangeDate + ", sourceOfChange=" + sourceOfChange + ", filler1=" + filler1
				+ ", policyHolderLastNM=" + policyHolderLastNM + ", policyHolderFirstNM=" + policyHolderFirstNM
				+ ", policyHolderMiddleInitial=" + policyHolderMiddleInitial + ", policyHolderAddrLine1="
				+ policyHolderAddrLine1 + ", policyHolderAddrLine2=" + policyHolderAddrLine2
				+ ", policyHolderCityState=" + policyHolderCityState + ", policyHolderZipCD=" + policyHolderZipCD
				+ ", policyHolderZip4=" + policyHolderZip4 + ", groupEmployerAddrLine1=" + groupEmployerAddrLine1
				+ ", groupEmployerAddrLine2=" + groupEmployerAddrLine2 + ", groupEmployerCityState="
				+ groupEmployerCityState + ", groupEmployerZipCD=" + groupEmployerZipCD + ", groupEmployerZip4="
				+ groupEmployerZip4 + ", bountyAddDate=" + bountyAddDate + ", bountyAddSource=" + bountyAddSource
				+ ", bountyAddCountyId=" + bountyAddCountyId + ", bountyAddEligWorkerCD=" + bountyAddEligWorkerCD
				+ ", bountyAddDistrict=" + bountyAddDistrict + ", bountyStatus=" + bountyStatus + ", filler2=" + filler2
				+ ", insertTimestamp=" + insertTimestamp + ", insertUser=" + insertUser + ", updateTimeStamp="
				+ updateTimeStamp + ", updateUser=" + updateUser + ", insertProcess=" + insertProcess
				+ ", insertProcessId=" + insertProcessId + ", updateProcess=" + updateProcess + ", updateProcessId="
				+ updateProcessId + "]";
	}

}
