package org.kpcc.ws.ppcl.service;

import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public interface FileLoaderService {

	/**
	 * This method can be used to fetch of landing zones available in the config table
	 * @return Map<String, String>
	 */
	public Map<String, String> getLZFromConfig();
	
	/**
	 * This method can be used to check the file type from the name provided
	 * @param name
	 * @return String
	 */
	public String getFileType(String name);
	
	/**
	 * This method reads the files available at the 'INBOUND' directory and saves the data to staging in KPCC DB
	 * @return String
	 */
	public String processPPFileFromLZ();
	
	/**
	 * This method transforms the staging data to ohc format
	 * @return String
	 */
	public String transformHISDBtoOHC();
	
	/**
	 * This method can be used to fetch of filters available in the config table
	 * @return Map<String, String>
	 */
	public Map<String, String> getFiltersFromConfig();
	
}
