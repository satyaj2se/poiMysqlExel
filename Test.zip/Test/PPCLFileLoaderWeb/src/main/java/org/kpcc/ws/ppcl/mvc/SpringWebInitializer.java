package org.kpcc.ws.ppcl.mvc;

import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.kpcc.ws.ppcl.context.PPCLContextListner;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

public class SpringWebInitializer implements WebApplicationInitializer{

	private static Logger logger = Logger.getLogger(SpringWebInitializer.class.getName());
	
	public SpringWebInitializer(){
		super();
	}
	
	@Override
	public void onStartup(ServletContext ctx) throws ServletException {
		// TODO Auto-generated method stub
		  AnnotationConfigWebApplicationContext webCtx = new AnnotationConfigWebApplicationContext();
		  webCtx.register(WebConfiguration.class);
		  webCtx.setServletContext(ctx);
		  ServletRegistration.Dynamic servlet = ctx.addServlet("dispatcher", new DispatcherServlet(webCtx));
		  servlet.setLoadOnStartup(1);
		  servlet.addMapping("/");
		  logger.info(">>>>>>PPCL Context Listener<<<<<<<"+ctx);
    	  //Add Listener.
		  ctx.addListener(new PPCLContextListner());
		  
	}
	
	

}
