package org.kpcc.ws.ppcl.dto;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@Table(name = "PPCL_RECORD_ERROR_T")
@Entity
public class PPCLFileRecordErrorDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "RECORD_ERROR_ID")
	Long recordErrorId;
	@Column(name = "RCVD_OHC_CARRIER_ID")
	Long rcvdOhcCarrierId;
	@Column(name = "PARTNER_ID")
	Long partnerId;
	@Column(name = "PROCESS_NAME")
	String processName;
	@Column(name = "MESSAGE")
	String message;
	@Column(name = "RESUBMIT_FLAG")
	String reSubmitFlag;
	@Column(name = "REGION_CODE")
	String regionCode;
	
	@Column(name = "INSERT_TIMESTAMP")
	Timestamp insertTimestamp;
	@Column(name = "INSERT_USER")
	String insertUser;
	@Column(name = "UPDATE_TIMESTAMP")
	Timestamp updateTimeStamp;
	@Column(name = "UPDATE_USER")
	String updateUser;
	
	@Column(name = "INSERT_PROCESS")
	String insertProcess;
	@Column(name = "INSERT_PROCESS_ID")
	Long insertProcessId;
	@Column(name = "UPDATE_PROCESS")
	String updateProcess;
	@Column(name = "UPDATE_PROCESS_ID")
	Long updateProcessId;

	public Long getRecordErrorId() {
		return recordErrorId;
	}
	public void setRecordErrorId(Long recordErrorId) {
		this.recordErrorId = recordErrorId;
	}
	public Long getRcvdOhcCarrierId() {
		return rcvdOhcCarrierId;
	}
	public void setRcvdOhcCarrierId(Long rcvdOhcCarrierId) {
		this.rcvdOhcCarrierId = rcvdOhcCarrierId;
	}
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getReSubmitFlag() {
		return reSubmitFlag;
	}
	public void setReSubmitFlag(String reSubmitFlag) {
		this.reSubmitFlag = reSubmitFlag;
	}
	public String getRegionCode() {
		return regionCode;
	}
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	public Timestamp getInsertTimestamp() {
		return insertTimestamp;
	}
	public void setInsertTimestamp(Timestamp insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}
	public String getInsertUser() {
		return insertUser;
	}
	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}
	public Timestamp getUpdateTimeStamp() {
		return updateTimeStamp;
	}
	public void setUpdateTimeStamp(Timestamp updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getInsertProcess() {
		return insertProcess;
	}
	public void setInsertProcess(String insertProcess) {
		this.insertProcess = insertProcess;
	}
	public Long getInsertProcessId() {
		return insertProcessId;
	}
	public void setInsertProcessId(Long insertProcessId) {
		this.insertProcessId = insertProcessId;
	}
	public String getUpdateProcess() {
		return updateProcess;
	}
	public void setUpdateProcess(String updateProcess) {
		this.updateProcess = updateProcess;
	}
	public Long getUpdateProcessId() {
		return updateProcessId;
	}
	public void setUpdateProcessId(Long updateProcessId) {
		this.updateProcessId = updateProcessId;
	}

	@Override
	public String toString() {
		return "PPCLFileRecordErrorDTO [recordErrorId=" + recordErrorId + ", rcvdOhcCarrierId=" + rcvdOhcCarrierId
				+ ", partnerId=" + partnerId + ", processName=" + processName + ", message=" + message
				+ ", reSubmitFlag=" + reSubmitFlag + ", regionCode=" + regionCode + ", insertTimestamp="
				+ insertTimestamp + ", insertUser=" + insertUser + ", updateTimeStamp=" + updateTimeStamp
				+ ", updateUser=" + updateUser + ", insertProcess=" + insertProcess + ", insertProcessId="
				+ insertProcessId + ", updateProcess=" + updateProcess + ", updateProcessId=" + updateProcessId + "]";
	}
	
}
