package org.kpcc.ws.ppcl.constants;

public enum PPCLErrorCodes {

	MRN_NULL("1001"),
	REGION_NULL("1002"),
	REGION_INVALID("1003"),
	ASOFDATE_REQUIRED("1004"),
	INVALID_ASOFDATE_FORMAT("1005"),
	MRN_INVALID("2001"),
	MRN_NOT_FOUND("2002"),
	MRN_UNAVAILABLE("2004"),
	COVERAGE_NOT_FOUND("2003"),
	KPCC_CALL_FAILURE("2005"),
	INVALID_GROUP_NUMBER("2006"),
	TIMEOUT_ERROR("2007"),
	MBI_SERVICE_ERROR_3001("3001"),
	MBI_SERVICE_ERROR_3002("3002"),
	MBI_SERVICE_ERROR_3003("3003"),
	MBI_SERVICE_ERROR_3004("3004");
	
	
	
	private final String errorCode;

	PPCLErrorCodes(String errorCode){
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public static PPCLErrorCodes fromValue(String v) {
		return valueOf(v);
	}
	
}
