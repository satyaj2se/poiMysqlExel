package org.kpcc.ws.ppcl.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class MEPDRMemberLookUpService {
	private static Logger logger = LogManager.getLogger(MEPDRMemberLookUpService.class);

	@Autowired
	@Qualifier("ppclDataSource")
	DataSource dataSource;
	/**
	 * This method will fetch the Member details from MEPDR, 
	 * @param ssn
	 * @return
	 * @throws SQLException
	 */
	public Map<String, String> getMemberDetails(String ssn) throws SQLException {
		Map<String, String> memberDetails = new HashMap<>();
		try (Connection connection = dataSource.getConnection()) {

			String INITIAL_CONFIG_QUERY = "select MBR_MRN,MBR_MBI,MBR_FIRST_NAME,MBR_MIDDLE_NAME,MBR_LAST_NAME,MBR_DOB,MBR_RESIDENCY_STR_ADDR_NAME,MBR_RESIDENCY_STR_ADD2_NAME,MBR_RESIDENCY_CTY_NAME,MBR_RESIDENCY_ST_NAME,MBR_RESIDENCY_ZIP_CODE,MBR_CONTACT_NUMBER,MBR_SSN from SBX_TBD.mepdr_dumb where MBR_SSN = ?";

			logger.info("---KPCC_CLAIMS_PLATFORM_CONFIG_T Querying---" + INITIAL_CONFIG_QUERY);

			try (PreparedStatement psConfig = connection.prepareStatement(INITIAL_CONFIG_QUERY)) {

				psConfig.setString(1, ssn);
				try (ResultSet rsConfig = psConfig.executeQuery()) {
					while (rsConfig.next()) {

						memberDetails.put("MBR_MRN", rsConfig.getString("MBR_MRN"));
						memberDetails.put("MBR_MBI", rsConfig.getString("MBR_MBI"));
						memberDetails.put("MBR_FIRST_NAME", rsConfig.getString("MBR_FIRST_NAME"));
						memberDetails.put("MBR_MIDDLE_NAME", rsConfig.getString("MBR_MIDDLE_NAME"));
						memberDetails.put("MBR_LAST_NAME", rsConfig.getString("MBR_LAST_NAME"));
						memberDetails.put("MBR_RESIDENCY_STR_ADDR_NAME",
								rsConfig.getString("MBR_RESIDENCY_STR_ADDR_NAME"));
						memberDetails.put("MBR_RESIDENCY_STR_ADD2_NAME",
								rsConfig.getString("MBR_RESIDENCY_STR_ADD2_NAME"));
						memberDetails.put("MBR_RESIDENCY_CTY_NAME", rsConfig.getString("MBR_RESIDENCY_CTY_NAME"));
						memberDetails.put("MBR_RESIDENCY_ST_NAME", rsConfig.getString("MBR_RESIDENCY_ST_NAME"));
						memberDetails.put("MBR_RESIDENCY_ZIP_CODE", rsConfig.getString("MBR_RESIDENCY_ZIP_CODE"));
						memberDetails.put("MBR_CONTACT_NUMBER", rsConfig.getString("MBR_CONTACT_NUMBER"));
						memberDetails.put("MBR_SSN", rsConfig.getString("MBR_SSN"));
					}
				}
			}
		}
		logger.info("---mepdr member details---" + memberDetails);
		return memberDetails;
	}

}
