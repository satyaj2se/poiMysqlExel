/**
 * 
 */
package org.kpcc.ws.ppcl.vo;

/**
 * @author S492749
 *
 */
public class PPCLResponse {
	
	private String status;
	private String code;
	private String message;

	public PPCLResponse(String status, String code, String message) {
		super();
		this.status = status;
		this.code = code;
		this.message = message;
	}
	
	public PPCLResponse() {
		super();
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "PPCLResponse [status=" + status + ", code=" + code + ", message=" + message + "]";
	}
	
}
