package org.kpcc.ws.ppcl.dto;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

/*POJO class corresponding to the table KPCCINT.PPCL_PIPEDLTD_STG_T*/

@Data
@Entity
@Table(name = "PPCL_PIPEDLTD_STG_T")
public class PPCLPipeStageDTO {
	@Column(name = "REGION_CODE")
	String regionCode;

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "RCVD_OHC_ID")
	Long rcvdOhcId;

	@Column(name = "RCVD_FILE_ID")
	Long rcvdFileId;

	
	@Column(name = "CIN") 
	String cin;

	@Column(name = "RECORD_STATUS")
	String recordStatus;

	@Column(name = "MEDS_ID")
	String medsId;
	@Column(name = "NBR_OF_INSURANCE_SEGMENTS")
	String nbrOfInsuranceSegments;
	@Column(name = "BENEFICIARY_PHONE_NBR")
	String beneficiaryPhoneNbr;
	@Column(name = "COUNTRY_WORKER_PHONE_NBR")
	String countyWorkerPhoneNumber;
	@Column(name = "MEDS_CURRENT_DATE")
	String medsCurrentYearMonth;
	@Column(name = "PENDING_OHC")
	String pendingOHC;

	@Column(name = "CARRIER_NAME1")
	String carrierName1;
	@Column(name = "CARRIER_NAME2")
	String carrierName2;

	@Column(name = "REFER_TO_CARRIER")
	String referToCarrier;
	@Column(name = "CARRIER_STREET_ADDRESS1")
	String carrierStreetAddress1;
	@Column(name = "CARRIER_STREET_ADDRESS2")
	String carrierStreetAddress2;

	@Column(name = "CARRIER_CITY")
	String carrierCity;
	@Column(name = "CARRIER_STATE")
	String carrierState;
	@Column(name = "CARRIER_ZIP")
	String carrierZip;
	@Column(name = "CARRIER_ZIP4")
	String carrierZip4;
	@Column(name = "CARRIER_PHONE")
	String carrierPhone;
	@Column(name = "CARRIER_PHONE_EXTENSION")
	String carrierPhoneExtension;
	@Column(name = "CARRIER_ATTENTION_LINE")
	String carrierAttentionLine;
	@Column(name = "CARRIER_FOOT_NOTE1")
	String carrierFootNote1;
	@Column(name = "CARRIER_FOOT_NOTE2")
	String carrierFootNote2;
	@Column(name = "CARRIER_TYPE")
	String carrierType;
	@Column(name = "CARRIER_OHC_CODE")
	String CarrierOHCCode;
	@Column(name = "CARRIER_STATUS_CODE")
	String carrierStatusCode;
	@Column(name = "CARRIER_CODE")
	String carrierCode;

	@Column(name = "POLICY_NUMBER")
	String policyNumber;
	@Column(name = "SEGMENT_TYP")
	String segmentType;
	@Column(name = "SCOPE_OF_COVERAGE")
	String ScopeofCoverage;
	@Column(name = "COV_O")
	String covO;
	@Column(name = "COV_I")
	String covI;
	@Column(name = "COV_M")
	String covM;
	@Column(name = "COV_L")
	String covL;
	@Column(name = "COV_P")
	String covP;
	@Column(name = "COV_D")
	String covD;
	@Column(name = "COV_V")
	String covV;
	@Column(name = "COV_R")
	String covR;
	@Column(name = "POLICY_START_DATE")
	String policyStartDate;
	@Column(name = "POLICY_STOP_DATE")
	String policyStopDate;
	@Column(name = "LAST_CHANGE_DATE")
	String lastChangeDate;
	@Column(name = "SOURCE_OF_CHANGE")
	String sourceOfChange;

	@Column(name = "RELATIONSHIP_TO_POLICY_HOLDER")
	String relationshiptoPolicyHolder;
	@Column(name = "DEPENDENT_COVERAGE_AVILABLE")
	String dependentCoverageAvilable;
	@Column(name = "TERMINATION_REASON")
	String terminationReason;

	@Column(name = "POLICY_HOLDER_LAST_NM")
	String policyHolderLastName;
	@Column(name = "POLICY_HOLDER_FIRST_NM")
	String policyHolderFirstName;

	@Column(name = "POLICY_HOLDER_MIDDILE_INITIAL")
	String policyHolderMiddleInitial;
	@Column(name = "POLICY_HOLDER_ADDR_LINE1")
	String policyHolderAddressLine1;

	@Column(name = "POLICY_HOLDER_ADDR_LINE2")
	String policyHolderAddressLine2;

	@Column(name = "POLICY_HOLDER_CITY_STATE")
	String policyHolderCityState;
	@Column(name = "POLICY_HOLDER_ZIP_CD")
	String policyHolderZipCode;
	@Column(name = "POLICY_HOLDER_PHONE_NBR")
	String policyHolderPhoneNumber;
	@Column(name = "POLICY_HOLDER_ZIP4")
	String policyHolderZip4;
	@Column(name = "INSERT_TIMESTAMP")
	Timestamp insertTimestamp;
	@Column(name = "INSERT_USER")
	String insertUser;
	@Column(name = "UPDATE_TIMESTAMP")
	Timestamp updateTimeStamp;
	@Column(name = "UPDATE_USER")
	String updateUser;

	@Column(name = "INSERT_PROCESS")
	String insertProcess;
	@Column(name = "INSERT_PROCESS_ID")
	Long insertProcessId;
	@Column(name = "UPDATE_PROCESS")
	String updateProcess;
	@Column(name = "UPDATE_PROCESS_ID")
	Long updateProcessId;

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public Long getRcvdOhcId() {
		return rcvdOhcId;
	}

	public void setRcvdOhcId(Long rcvdOhcId) {
		this.rcvdOhcId = rcvdOhcId;
	}

	public Long getRcvdFileId() {
		return rcvdFileId;
	}

	public void setRcvdFileId(Long rcvdFileId) {
		this.rcvdFileId = rcvdFileId;
	}

	

	public String getCin() {
		return cin;
	}

	public void setCin(String cin) {
		this.cin = cin;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public String getMedsId() {
		return medsId;
	}

	public void setMedsId(String medsId) {
		this.medsId = medsId;
	}

	public String getNbrOfInsuranceSegments() {
		return nbrOfInsuranceSegments;
	}

	public void setNbrOfInsuranceSegments(String nbrOfInsuranceSegments) {
		this.nbrOfInsuranceSegments = nbrOfInsuranceSegments;
	}

	public String getBeneficiaryPhoneNbr() {
		return beneficiaryPhoneNbr;
	}

	public void setBeneficiaryPhoneNbr(String beneficiaryPhoneNbr) {
		this.beneficiaryPhoneNbr = beneficiaryPhoneNbr;
	}

	
	public String getCountyWorkerPhoneNumber() {
		return countyWorkerPhoneNumber;
	}

	public void setCountyWorkerPhoneNumber(String countyWorkerPhoneNumber) {
		this.countyWorkerPhoneNumber = countyWorkerPhoneNumber;
	}

	
	public String getPendingOHC() {
		return pendingOHC;
	}

	public void setPendingOHC(String pendingOHC) {
		this.pendingOHC = pendingOHC;
	}

	public String getCarrierName1() {
		return carrierName1;
	}

	public void setCarrierName1(String carrierName1) {
		this.carrierName1 = carrierName1;
	}

	public String getCarrierName2() {
		return carrierName2;
	}

	public void setCarrierName2(String carrierName2) {
		this.carrierName2 = carrierName2;
	}

	public String getReferToCarrier() {
		return referToCarrier;
	}

	public void setReferToCarrier(String referToCarrier) {
		this.referToCarrier = referToCarrier;
	}

	public String getCarrierStreetAddress1() {
		return carrierStreetAddress1;
	}

	public void setCarrierStreetAddress1(String carrierStreetAddress1) {
		this.carrierStreetAddress1 = carrierStreetAddress1;
	}

	public String getCarrierStreetAddress2() {
		return carrierStreetAddress2;
	}

	public void setCarrierStreetAddress2(String carrierStreetAddress2) {
		this.carrierStreetAddress2 = carrierStreetAddress2;
	}

	public String getCarrierCity() {
		return carrierCity;
	}

	public void setCarrierCity(String carrierCity) {
		this.carrierCity = carrierCity;
	}

	public String getCarrierState() {
		return carrierState;
	}

	public void setCarrierState(String carrierState) {
		this.carrierState = carrierState;
	}

	public String getCarrierZip() {
		return carrierZip;
	}

	public void setCarrierZip(String carrierZip) {
		this.carrierZip = carrierZip;
	}

	

	public String getCarrierZip4() {
		return carrierZip4;
	}

	public void setCarrierZip4(String carrierZip4) {
		this.carrierZip4 = carrierZip4;
	}

	public String getCarrierPhone() {
		return carrierPhone;
	}

	public void setCarrierPhone(String carrierPhone) {
		this.carrierPhone = carrierPhone;
	}

	public String getCarrierPhoneExtension() {
		return carrierPhoneExtension;
	}

	public void setCarrierPhoneExtension(String carrierPhoneExtension) {
		this.carrierPhoneExtension = carrierPhoneExtension;
	}

	public String getCarrierAttentionLine() {
		return carrierAttentionLine;
	}

	public void setCarrierAttentionLine(String carrierAttentionLine) {
		this.carrierAttentionLine = carrierAttentionLine;
	}

	public String getCarrierFootNote1() {
		return carrierFootNote1;
	}

	public void setCarrierFootNote1(String carrierFootNote1) {
		this.carrierFootNote1 = carrierFootNote1;
	}

	public String getCarrierFootNote2() {
		return carrierFootNote2;
	}

	public void setCarrierFootNote2(String carrierFootNote2) {
		this.carrierFootNote2 = carrierFootNote2;
	}

	public String getCarrierType() {
		return carrierType;
	}

	public void setCarrierType(String carrierType) {
		this.carrierType = carrierType;
	}

	
	public String getCarrierStatusCode() {
		return carrierStatusCode;
	}

	public void setCarrierStatusCode(String carrierStatusCode) {
		this.carrierStatusCode = carrierStatusCode;
	}

	public String getCarrierCode() {
		return carrierCode;
	}

	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getSegmentType() {
		return segmentType;
	}

	public void setSegmentType(String segmentType) {
		this.segmentType = segmentType;
	}

	

	public String getCovO() {
		return covO;
	}

	public void setCovO(String covO) {
		this.covO = covO;
	}

	public String getCovI() {
		return covI;
	}

	public void setCovI(String covI) {
		this.covI = covI;
	}

	public String getCovM() {
		return covM;
	}

	public void setCovM(String covM) {
		this.covM = covM;
	}

	public String getCovL() {
		return covL;
	}

	public void setCovL(String covL) {
		this.covL = covL;
	}

	public String getCovP() {
		return covP;
	}

	public void setCovP(String covP) {
		this.covP = covP;
	}

	public String getCovD() {
		return covD;
	}

	public void setCovD(String covD) {
		this.covD = covD;
	}

	public String getCovV() {
		return covV;
	}

	public void setCovV(String covV) {
		this.covV = covV;
	}

	public String getCovR() {
		return covR;
	}

	public void setCovR(String covR) {
		this.covR = covR;
	}

	
	public String getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public String getPolicyStopDate() {
		return policyStopDate;
	}

	public void setPolicyStopDate(String policyStopDate) {
		this.policyStopDate = policyStopDate;
	}

	public String getLastChangeDate() {
		return lastChangeDate;
	}

	public void setLastChangeDate(String lastChangeDate) {
		this.lastChangeDate = lastChangeDate;
	}

	public String getSourceOfChange() {
		return sourceOfChange;
	}

	public void setSourceOfChange(String sourceOfChange) {
		this.sourceOfChange = sourceOfChange;
	}

	
	public String getMedsCurrentYearMonth() {
		return medsCurrentYearMonth;
	}

	public void setMedsCurrentYearMonth(String medsCurrentYearMonth) {
		this.medsCurrentYearMonth = medsCurrentYearMonth;
	}

	public String getCarrierOHCCode() {
		return CarrierOHCCode;
	}

	public void setCarrierOHCCode(String carrierOHCCode) {
		CarrierOHCCode = carrierOHCCode;
	}

	public String getScopeofCoverage() {
		return ScopeofCoverage;
	}

	public void setScopeofCoverage(String scopeofCoverage) {
		ScopeofCoverage = scopeofCoverage;
	}

	public String getRelationshiptoPolicyHolder() {
		return relationshiptoPolicyHolder;
	}

	public void setRelationshiptoPolicyHolder(String relationshiptoPolicyHolder) {
		this.relationshiptoPolicyHolder = relationshiptoPolicyHolder;
	}

	public String getDependentCoverageAvilable() {
		return dependentCoverageAvilable;
	}

	public void setDependentCoverageAvilable(String dependentCoverageAvilable) {
		this.dependentCoverageAvilable = dependentCoverageAvilable;
	}

	public String getTerminationReason() {
		return terminationReason;
	}

	public void setTerminationReason(String terminationReason) {
		this.terminationReason = terminationReason;
	}

	public String getPolicyHolderLastName() {
		return policyHolderLastName;
	}

	public void setPolicyHolderLastName(String policyHolderLastName) {
		this.policyHolderLastName = policyHolderLastName;
	}

	public String getPolicyHolderFirstName() {
		return policyHolderFirstName;
	}

	public void setPolicyHolderFirstName(String policyHolderFirstName) {
		this.policyHolderFirstName = policyHolderFirstName;
	}

	

	public String getPolicyHolderMiddleInitial() {
		return policyHolderMiddleInitial;
	}

	public void setPolicyHolderMiddleInitial(String policyHolderMiddleInitial) {
		this.policyHolderMiddleInitial = policyHolderMiddleInitial;
	}

	public String getPolicyHolderAddressLine1() {
		return policyHolderAddressLine1;
	}

	public void setPolicyHolderAddressLine1(String policyHolderAddressLine1) {
		this.policyHolderAddressLine1 = policyHolderAddressLine1;
	}

	public String getPolicyHolderAddressLine2() {
		return policyHolderAddressLine2;
	}

	public void setPolicyHolderAddressLine2(String policyHolderAddressLine2) {
		this.policyHolderAddressLine2 = policyHolderAddressLine2;
	}

	public String getPolicyHolderCityState() {
		return policyHolderCityState;
	}

	public void setPolicyHolderCityState(String policyHolderCityState) {
		this.policyHolderCityState = policyHolderCityState;
	}

	public String getPolicyHolderZipCode() {
		return policyHolderZipCode;
	}

	public void setPolicyHolderZipCode(String policyHolderZipCode) {
		this.policyHolderZipCode = policyHolderZipCode;
	}

	public String getPolicyHolderPhoneNumber() {
		return policyHolderPhoneNumber;
	}

	public void setPolicyHolderPhoneNumber(String policyHolderPhoneNumber) {
		this.policyHolderPhoneNumber = policyHolderPhoneNumber;
	}

	public String getPolicyHolderZip4() {
		return policyHolderZip4;
	}

	public void setPolicyHolderZip4(String policyHolderZip4) {
		this.policyHolderZip4 = policyHolderZip4;
	}

	public Timestamp getInsertTimestamp() {
		return insertTimestamp;
	}

	public void setInsertTimestamp(Timestamp insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}

	public String getInsertUser() {
		return insertUser;
	}

	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}

	public Timestamp getUpdateTimeStamp() {
		return updateTimeStamp;
	}

	public void setUpdateTimeStamp(Timestamp updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getInsertProcess() {
		return insertProcess;
	}

	public void setInsertProcess(String insertProcess) {
		this.insertProcess = insertProcess;
	}

	public Long getInsertProcessId() {
		return insertProcessId;
	}

	public void setInsertProcessId(Long insertProcessId) {
		this.insertProcessId = insertProcessId;
	}

	public String getUpdateProcess() {
		return updateProcess;
	}

	public void setUpdateProcess(String updateProcess) {
		this.updateProcess = updateProcess;
	}

	public Long getUpdateProcessId() {
		return updateProcessId;
	}

	public void setUpdateProcessId(Long updateProcessId) {
		this.updateProcessId = updateProcessId;
	}

}
