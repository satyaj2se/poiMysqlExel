package org.kpcc.ws.ppcl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PPCLFileLoaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
